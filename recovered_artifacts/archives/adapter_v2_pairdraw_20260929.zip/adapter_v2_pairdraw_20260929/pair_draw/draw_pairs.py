#!/usr/bin/env python3
"""Generate the ordered pair list defined by pair_draw_precommit_20260929.json."""
import csv, hashlib, itertools, json, sys
from pathlib import Path

pre_path, adapter_root, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
pre = json.loads(pre_path.read_text())
runs = {7: "rank07", 9: "rank09", 14: "regress_rank14"}
pairs = []
for p in pre["projects"]:
    sm = json.load(open(adapter_root / runs[p["rank"]] / "manifests" / "semantic_manifest.json"))
    names = sorted(m["name"] for m in sm["metrics"])
    for a, b in itertools.combinations(names, 2):
        key = f'{p["repo"]}@{p["commit"]}|{a}|{b}'
        pairs.append({"sort_hash": hashlib.sha256(f"saner27-pairdraw-v1|{key}".encode()).hexdigest(),
                      "repo": p["repo"], "commit": p["commit"], "project_subdir": p["project_subdir"],
                      "metric_a": a, "metric_b": b})
pairs.sort(key=lambda r: r["sort_hash"])
for i, r in enumerate(pairs, 1):
    r["pair_code"], r["batch"] = f"P-{i:02d}", (i - 1) // 13 + 1
cols = ["pair_code", "batch", "repo", "commit", "project_subdir", "metric_a", "metric_b", "sort_hash"]
with open(out, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=cols)
    w.writeheader()
    w.writerows({c: r[c] for c in cols} for r in pairs)
print(json.dumps({"pairs": len(pairs), "precommit_sha256": hashlib.sha256(pre_path.read_bytes()).hexdigest()}))
