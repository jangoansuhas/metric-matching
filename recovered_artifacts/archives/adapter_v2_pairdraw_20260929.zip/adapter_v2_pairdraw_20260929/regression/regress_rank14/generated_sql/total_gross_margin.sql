SELECT
  SUM(gross_margin) AS total_gross_margin
FROM "dev"."main"."fct_orders" orders_src_10000
