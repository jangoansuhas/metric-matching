SELECT
  SUM(revenue) AS total_revenue
FROM "dev"."main"."fct_orders" orders_src_10000
