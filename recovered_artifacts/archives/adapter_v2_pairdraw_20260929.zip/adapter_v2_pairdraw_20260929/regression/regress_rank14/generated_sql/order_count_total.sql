SELECT
  SUM(1) AS order_count_total
FROM "dev"."main"."fct_orders" orders_src_10000
