SELECT
  SUM(otif_flag) AS otif_orders_count
FROM "dev"."main"."fct_orders" orders_src_10000
