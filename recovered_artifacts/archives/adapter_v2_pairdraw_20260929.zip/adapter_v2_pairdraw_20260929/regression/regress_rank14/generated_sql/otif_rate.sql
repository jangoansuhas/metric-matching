SELECT
  CAST(SUM(otif_flag) AS DOUBLE) / CAST(NULLIF(SUM(1), 0) AS DOUBLE) AS otif_rate
FROM "dev"."main"."fct_orders" orders_src_10000
