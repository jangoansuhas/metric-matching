SELECT
  SUM(revenue) AS total_revenue
FROM "dev"."main_marts"."fct_revenue" revenue_src_10000
