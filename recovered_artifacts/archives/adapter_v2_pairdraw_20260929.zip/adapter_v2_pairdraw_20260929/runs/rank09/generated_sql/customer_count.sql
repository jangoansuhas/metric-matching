SELECT
  SUM(CASE WHEN customer_id IS NOT NULL THEN 1 ELSE 0 END) AS customer_count
FROM "dev"."main_marts"."dim_customers" customers_src_10000
