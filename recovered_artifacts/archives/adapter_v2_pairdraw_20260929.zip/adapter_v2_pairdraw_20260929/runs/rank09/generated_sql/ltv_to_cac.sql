SELECT
  ltv / nullif(cac, 0) AS ltv_to_cac
FROM (
  SELECT
    CAST(SUM(lifetime_revenue) AS DOUBLE) / CAST(NULLIF(SUM(CASE WHEN customer_id IS NOT NULL THEN 1 ELSE 0 END), 0) AS DOUBLE) AS ltv
    , CAST(SUM(cac_cost) AS DOUBLE) / CAST(NULLIF(SUM(CASE WHEN customer_id IS NOT NULL THEN 1 ELSE 0 END), 0) AS DOUBLE) AS cac
  FROM "dev"."main_marts"."dim_customers" customers_src_10000
) subq_6
