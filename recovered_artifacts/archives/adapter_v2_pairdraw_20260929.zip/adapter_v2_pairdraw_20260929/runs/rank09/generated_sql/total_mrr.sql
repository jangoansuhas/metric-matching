SELECT
  SUM(total_mrr) AS total_mrr
FROM "dev"."main_marts"."dim_customers" customers_src_10000
