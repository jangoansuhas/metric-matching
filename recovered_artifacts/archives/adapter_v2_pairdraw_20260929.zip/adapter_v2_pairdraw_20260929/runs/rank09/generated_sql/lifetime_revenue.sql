SELECT
  SUM(lifetime_revenue) AS lifetime_revenue
FROM "dev"."main_marts"."dim_customers" customers_src_10000
