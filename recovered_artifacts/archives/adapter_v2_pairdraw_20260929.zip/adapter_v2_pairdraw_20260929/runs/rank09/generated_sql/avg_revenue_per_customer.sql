SELECT
  CAST(MAX(subq_5.total_revenue) AS DOUBLE) / CAST(NULLIF(MAX(subq_11.customer_count), 0) AS DOUBLE) AS avg_revenue_per_customer
FROM (
  SELECT
    SUM(revenue) AS total_revenue
  FROM "dev"."main_marts"."fct_revenue" revenue_src_10000
) subq_5
CROSS JOIN (
  SELECT
    SUM(CASE WHEN customer_id IS NOT NULL THEN 1 ELSE 0 END) AS customer_count
  FROM "dev"."main_marts"."dim_customers" customers_src_10000
) subq_11
