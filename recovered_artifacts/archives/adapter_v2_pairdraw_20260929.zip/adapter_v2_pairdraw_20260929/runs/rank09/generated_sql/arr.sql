SELECT
  mrr * 12 AS arr
FROM (
  SELECT
    SUM(total_mrr) AS mrr
  FROM "dev"."main_marts"."dim_customers" customers_src_10000
) subq_5
