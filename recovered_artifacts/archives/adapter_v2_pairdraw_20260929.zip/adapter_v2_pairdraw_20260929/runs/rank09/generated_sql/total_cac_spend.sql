SELECT
  SUM(cac_cost) AS total_cac_spend
FROM "dev"."main_marts"."dim_customers" customers_src_10000
