SELECT
  CAST(SUM(lifetime_revenue) AS DOUBLE) / CAST(NULLIF(SUM(CASE WHEN customer_id IS NOT NULL THEN 1 ELSE 0 END), 0) AS DOUBLE) AS ltv
FROM "dev"."main_marts"."dim_customers" customers_src_10000
