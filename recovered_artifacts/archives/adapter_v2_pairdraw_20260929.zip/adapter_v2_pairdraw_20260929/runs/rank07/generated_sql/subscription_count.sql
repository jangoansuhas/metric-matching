SELECT
  SUM(CASE WHEN event_id IS NOT NULL THEN 1 ELSE 0 END) AS subscription_count
FROM "dev"."main_mart"."fct_subscription" subscription_src_10000
