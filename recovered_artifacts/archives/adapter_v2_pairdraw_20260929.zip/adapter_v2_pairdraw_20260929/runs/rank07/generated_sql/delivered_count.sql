SELECT
  SUM(case when event_type = 'delivered' then 1 else 0 end) AS delivered_count
FROM "dev"."main_mart"."fct_message_event" message_event_src_10000
