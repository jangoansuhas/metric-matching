SELECT
  CAST(SUM(case when event_type = 'clicked' then 1 else 0 end) AS DOUBLE) / CAST(NULLIF(SUM(case when event_type = 'delivered' then 1 else 0 end), 0) AS DOUBLE) AS ctr
FROM "dev"."main_mart"."fct_message_event" message_event_src_10000
