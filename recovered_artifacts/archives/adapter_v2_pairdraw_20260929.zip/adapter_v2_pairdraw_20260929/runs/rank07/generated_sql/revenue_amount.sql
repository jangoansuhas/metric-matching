SELECT
  SUM(case when is_latest_snapshot then revenue_amount else 0 end) AS revenue_amount
FROM "dev"."main_mart"."fct_revenue" revenue_src_10000
