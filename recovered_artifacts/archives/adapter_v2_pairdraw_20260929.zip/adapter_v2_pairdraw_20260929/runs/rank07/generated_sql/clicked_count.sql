SELECT
  SUM(case when event_type = 'clicked' then 1 else 0 end) AS clicked_count
FROM "dev"."main_mart"."fct_message_event" message_event_src_10000
