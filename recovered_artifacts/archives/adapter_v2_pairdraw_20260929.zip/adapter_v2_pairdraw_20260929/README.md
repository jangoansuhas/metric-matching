# Adapter v2 and pair draw (2026-09-29)

This bundle is technical evidence produced by an AI (Claude), for verification. It contains no relationship labels, method predictions or metric values.

## Adapter v2
- **File:** `adapter_v2/run_adapter_v2.py`.
- **Changes from v1** (v1 SHA-256 `7b90ef37…fe09fe`, unchanged): an optional `--project-subdir`, and `--repo`/`--out` converted to absolute paths. `v1_to_v2.diff` is the complete diff.
- **Regression** (`regression/`), with v2 run without `--project-subdir`:
  - Jaffle `7be2c58`: all 19 SQL files byte-identical to v1 run `run_jaffle_20260928T170529Z`. `provenance.json` differs only in a log path and timestamp inside one error message (`revenue_growth_mom`, whose ungrouped query fails and whose metric_time query succeeds, as in v1).
  - Rank 14: `provenance.json` and all 5 SQL files identical to the v1 run.
- **Held-out coverage** (`runs/`), with parse exit 0 for both:

  | Project | Subdir | Metrics compiled ungrouped | Semantic models | Metric types |
  | --- | --- | --- | --- | --- |
  | Rank 7 | `dbt_project` | 5/5 | 3 | simple, ratio |
  | Rank 9 | `dbt` | 10/10 | 2 | simple, ratio, derived |

  With rank 14 (5/5, from v1 and the regression), all 20 declared metrics compile.
- **No values were computed.** The DuckDB file has no tables after explain, as `logs/20_duckdb_inventory.stdout` shows (`[]`).

## Pair draw
1. `pair_draw/pair_draw_precommit_20260929.json` was written and hashed, and made read-only, **before** the list was generated. Its SHA-256 is `2f5215fa…77d3`.
2. `draw_pairs.py` generated `pair_list_20260929.csv`. Pairs are ordered by a salted SHA-256 key and coded P-01 to P-65, in 5 batches of 13.
3. The pairs come from the three projects as follows:

   | Project | Pairs |
   | --- | --- |
   | Rank 9 | 45 |
   | Rank 7 | 10 |
   | Rank 14 | 10 |

The target is a census of all 65 pairs. The minimum is batches 1–2.

## Open items
- **Setup sheets for each project.** Reviewers need one before they receive the packets. Rank 9 targets Snowflake, so whether a local DuckDB build works is untested.
- **Testing the setup sheets.** A test means running `dbt build`, which builds tables. The proposed limit is `dbt build` plus `mf list metrics`, with no metric queries by the method team until the labels are locked.
- **Bundle naming.** The pair list names the metrics. It goes into the reviewer packets, where the pair codes stay neutral.
