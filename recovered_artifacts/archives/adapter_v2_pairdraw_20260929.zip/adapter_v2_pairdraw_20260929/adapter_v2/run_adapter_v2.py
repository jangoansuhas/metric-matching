#!/usr/bin/env python3
"""Compiled-metric provenance adapter for a pinned dbt repository (development tool), v2.

v2 differs from v1 (sha256 7b90ef37...fe09fe) only in: optional --project-subdir for a dbt
project nested inside the repository, and --repo/--out resolved to absolute paths.

For one repo + commit:
  1. verify the commit and export it with `git archive` into a fresh directory;
  2. write a local DuckDB profile (no credentials, no remote warehouse);
  3. run `dbt deps` and `dbt parse --no-partial-parse` under a scrubbed environment;
  4. for every metric in the fresh semantic manifest, record the declared binding chain
     (metric -> input measures -> semantic model -> dbt model) from the fresh artifacts,
     plus text-located YAML line spans;
  5. run `mf query --metrics <m> --explain` (retrying with `--group-by metric_time` on failure)
     and save the generated SQL;
  6. write provenance.json / provenance.csv, logs, SHA256SUMS (excluding itself), and a ZIP.

Usage:
  run_adapter_v2.py --repo /path/to/clone --commit <sha> --out /path/to/new_dir --venv /path/to/venv [--project-subdir dbt]
"""
import argparse, csv, hashlib, json, os, re, shutil, subprocess, sys, time, zipfile
from datetime import datetime, timezone
from pathlib import Path


def utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


ANSI = re.compile(r"\x1b\[[0-9;]*m")


class Runner:
    """Runs commands with `env -i`-equivalent environment and logs everything."""

    def __init__(self, out, venv):
        self.out, self.logs = out, out / "logs"
        self.logs.mkdir(parents=True, exist_ok=True)
        (out / "home").mkdir(exist_ok=True)
        self.env = {
            "HOME": str(out / "home"),
            "PATH": f"{venv}/bin:/usr/bin:/bin",
            "LANG": "C.UTF-8",
            "DBT_PROFILES_DIR": str(out / "profiles"),
            "DBT_SEND_ANONYMOUS_USAGE_STATS": "false",
            "DO_NOT_TRACK": "1",
        }
        self.commands = []

    def run(self, tag, cmd, cwd, timeout=600):
        start_utc, t0 = utc(), time.time()
        try:
            p = subprocess.run(cmd, cwd=cwd, env=self.env, capture_output=True, text=True, timeout=timeout)
            rc, so, se = p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired as e:
            rc, so, se = "timeout", (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or ""), f"TIMEOUT after {timeout}s"
        elapsed = round(time.time() - t0, 2)
        (self.logs / f"{tag}.stdout").write_text(so)
        (self.logs / f"{tag}.stderr").write_text(se)
        rec = {"tag": tag, "cmd": " ".join(cmd), "cwd": str(cwd), "exit": rc, "elapsed_s": elapsed, "start_utc": start_utc}
        (self.logs / f"{tag}.exit").write_text(json.dumps(rec) + "\n")
        self.commands.append(rec)
        return rc, ANSI.sub("", so), se


def yaml_span(path, top_key, name, parent=None):
    """Text-locate `- name: <name>` under top-level `top_key:` (optionally inside the list item
    `- name: <parent>` and its `measures:` key). Returns (start, end) 1-based lines or None.
    Heuristic: YAML line numbers are not in dbt artifacts, so this is labelled text-located."""
    if not path.exists():
        return None
    lines = path.read_text().splitlines()
    ind = lambda s: len(s) - len(s.lstrip(" "))

    def block(lo, hi, key_re):
        for i in range(lo, hi):
            if re.match(key_re, lines[i]):
                base = ind(lines[i])
                j = i + 1
                while j < hi and (not lines[j].strip() or lines[j].lstrip().startswith("#") or ind(lines[j]) > base
                                  or (ind(lines[j]) == base and lines[j].lstrip().startswith("- "))):
                    j += 1
                return i, j
        return None

    top = block(0, len(lines), rf"^{top_key}:\s*$")
    if not top:
        return None
    lo, hi = top
    if parent:
        item = find_item(lines, lo + 1, hi, parent)
        if not item:
            return None
        mb = block(item[0], item[1], r"^\s*measures:\s*$")
        if not mb:
            return None
        lo, hi = mb
    found = find_item(lines, lo + 1, hi, name)
    if not found:
        return None
    s, e = found
    while e - 1 > s and (not lines[e - 1].strip() or lines[e - 1].lstrip().startswith("#")):
        e -= 1
    return s + 1, e


def find_item(lines, lo, hi, name):
    ind = lambda s: len(s) - len(s.lstrip(" "))
    for i in range(lo, hi):
        m = re.match(rf"^(\s*)-\s*name:\s*['\"]?{re.escape(name)}['\"]?\s*$", lines[i])
        if m:
            base = ind(lines[i])
            j = i + 1
            while j < hi and not (lines[j].strip() and not lines[j].lstrip().startswith("#") and
                                  (ind(lines[j]) < base or (ind(lines[j]) == base and lines[j].lstrip().startswith("- ")))):
                j += 1
            return i, j
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--commit", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--venv", required=True)
    ap.add_argument("--project-subdir", default="", help="dbt project directory relative to the repository root")
    a = ap.parse_args()
    a.repo, a.out = str(Path(a.repo).resolve()), str(Path(a.out).resolve())
    out = Path(a.out)
    if out.exists():
        sys.exit(f"--out {out} exists; use a fresh directory")
    out.mkdir(parents=True)
    export = out / "project"
    proj = export / a.project_subdir if a.project_subdir else export
    R = Runner(out, a.venv)
    meta = {"run_start_utc": utc(), "repo": a.repo, "commit": a.commit, "adapter_script_sha256": sha256(__file__), "adapter_version": 2, "project_subdir": a.project_subdir}

    # 1. verify commit and export
    t = subprocess.run(["git", "-C", a.repo, "cat-file", "-t", a.commit], capture_output=True, text=True)
    if t.stdout.strip() != "commit":
        (out / "FAILED.txt").write_text(f"commit {a.commit} not found in {a.repo}: {t.stderr}")
        sys.exit("commit not found; stopping")
    meta["remote_url"] = subprocess.run(["git", "-C", a.repo, "remote", "get-url", "origin"], capture_output=True, text=True).stdout.strip()
    export.mkdir()
    archive_cmd = ["git", "-C", a.repo, "archive", "--format=tar", a.commit]
    tar = subprocess.run(archive_cmd, capture_output=True, check=True).stdout
    meta["archive_tar_sha256"] = hashlib.sha256(tar).hexdigest()
    subprocess.run(["tar", "-x", "-C", str(export)], input=tar, check=True)
    listing = subprocess.run(["tar", "-t"], input=tar, capture_output=True, check=True).stdout.decode()
    (R.logs / "git_archive_filelist.txt").write_text(listing)
    (R.logs / "git_archive.exit").write_text(json.dumps({
        "cmd": " ".join(archive_cmd) + f" | tar -x -C {export}", "exit": 0, "start_utc": utc(),
        "tar_sha256": meta["archive_tar_sha256"], "tar_entries": len(listing.splitlines())}) + "\n")
    meta["export_had_target_dir"] = (proj / "target").exists()
    if not (proj / "dbt_project.yml").exists():
        meta["failure_stage"] = "no dbt_project.yml in project dir"
        (R.logs / "project_dir_check.txt").write_text(f"missing {proj}/dbt_project.yml\n")
        finish(out, meta, R, [], a)
        return
    inputs = out / "inputs"
    inputs.mkdir()
    for f in ("dbt_project.yml", "packages.yml", "package-lock.yml", "dependencies.yml"):
        if (proj / f).exists():
            shutil.copy(proj / f, inputs / f"{f}.original")
            meta[f"sha256_{f}"] = sha256(proj / f)

    # 2. local DuckDB profile named after the project's `profile:` key
    m = re.search(r"^profile:\s*['\"]?([\w-]+)", (proj / "dbt_project.yml").read_text(), re.M)
    profile = m.group(1) if m else "default"
    (out / "profiles").mkdir()
    (out / "profiles" / "profiles.yml").write_text(
        f"{profile}:\n  target: dev\n  outputs:\n    dev:\n      type: duckdb\n      path: {out}/dev.duckdb\n      threads: 1\n")
    shutil.copy(out / "profiles" / "profiles.yml", inputs / "profiles.yml")
    meta["profile_name"] = profile
    meta["clean_env"] = R.env

    # environment record
    R.run("00_python_version", [f"{a.venv}/bin/python", "--version"], out)
    R.run("00_dbt_version", ["dbt", "--version"], out)
    R.run("00_mf_version", ["mf", "--version"], out)
    R.run("00_pip_freeze", [f"{a.venv}/bin/python", "-m", "pip", "freeze"], out)
    meta["os"] = Path("/etc/os-release").read_text().splitlines()[0] if Path("/etc/os-release").exists() else "unknown"
    meta["uname"] = " ".join(os.uname())

    dbt_args = ["--project-dir", str(proj), "--profiles-dir", str(out / "profiles")]
    # 3. deps + parse
    has_deps = any((proj / f).exists() for f in ("packages.yml", "dependencies.yml"))
    if has_deps:
        rc, so, _ = R.run("01_dbt_deps", ["dbt", "deps", *dbt_args], out, timeout=600)
        if (proj / "package-lock.yml").exists():
            shutil.copy(proj / "package-lock.yml", inputs / "package-lock.yml.after_deps")
            meta["sha256_package-lock.yml_after_deps"] = sha256(proj / "package-lock.yml")
        meta["deps_installed_lines"] = re.findall(r"Install(?:ing|ed from) [^\n]+", so)
    rc, so, se = R.run("02_dbt_parse", ["dbt", "parse", "--no-partial-parse", *dbt_args], out, timeout=600)
    meta["parse_exit"] = rc
    arts = out / "manifests"
    arts.mkdir()
    if rc != 0 or not (proj / "target" / "semantic_manifest.json").exists():
        meta["failure_stage"] = "dbt parse"
        finish(out, meta, R, [], a)
        return
    for f in ("manifest.json", "semantic_manifest.json"):
        shutil.copy(proj / "target" / f, arts / f)
        meta[f"sha256_{f}_after_parse"] = sha256(arts / f)
    man = json.load(open(arts / "manifest.json"))
    sm = json.load(open(arts / "semantic_manifest.json"))
    meta["manifest_metadata"] = {k: man["metadata"].get(k) for k in ("dbt_version", "generated_at", "invocation_id", "adapter_type", "project_name")}

    # 4. binding chain per metric
    measure_owners = {}
    for s in sm["semantic_models"]:
        for me in s.get("measures", []):
            measure_owners.setdefault(me["name"], []).append((s, me))
    man_metric = {v["name"]: v for v in man["metrics"].values()}
    man_sm = {v["name"]: v for v in man["semantic_models"].values()}
    sqldir = out / "generated_sql"
    sqldir.mkdir()
    rows = []
    for i, met in enumerate(sm["metrics"]):
        name, tp = met["name"], met["type_params"]
        mn = man_metric.get(name, {})
        decl_file = mn.get("original_file_path")
        span = yaml_span(proj / decl_file, "metrics", name) if decl_file else None
        measures = []
        for im in tp.get("input_measures") or []:
            owners = measure_owners.get(im["name"], [])
            entry = {"measure": im["name"], "filter": im.get("filter"), "fill_nulls_with": im.get("fill_nulls_with"),
                     "join_to_timespine": im.get("join_to_timespine"), "owner_count": len(owners), "owners": []}
            for s, me in owners:
                msn = man_sm.get(s["name"], {})
                f = msn.get("original_file_path")
                entry["owners"].append({
                    "semantic_model": s["name"], "semantic_model_file": f,
                    "semantic_model_span": yaml_span(proj / f, "semantic_models", s["name"]) if f else None,
                    "measure_span": yaml_span(proj / f, "semantic_models", me["name"], parent=s["name"]) if f else None,
                    "agg": me.get("agg"), "expr": me.get("expr"), "agg_time_dimension": me.get("agg_time_dimension") or (s.get("defaults") or {}).get("agg_time_dimension"),
                    "non_additive_dimension": me.get("non_additive_dimension"),
                    "node_relation": (s.get("node_relation") or {}).get("relation_name"),
                    "model_node": (msn.get("depends_on") or {}).get("nodes"),
                })
            measures.append(entry)
        rec = {
            "metric": name, "type": met["type"], "description": met.get("description"),
            "declared_file": decl_file, "declared_span_text_located": span,
            "metric_filter": met.get("filter"), "type_params_expr": tp.get("expr"),
            "numerator": (tp.get("numerator") or {}).get("name") if tp.get("numerator") else None,
            "denominator": (tp.get("denominator") or {}).get("name") if tp.get("denominator") else None,
            "input_metrics": [{"name": x["name"], "alias": x.get("alias"), "offset_window": x.get("offset_window"),
                               "filter": x.get("filter")} for x in tp.get("metrics") or []],
            "cumulative_type_params": tp.get("cumulative_type_params"),
            "manifest_depends_on": (mn.get("depends_on") or {}).get("nodes"),
            "input_measures": measures,
        }
        # 5. mf explain
        attempts = []
        for j, extra in enumerate(([], ["--group-by", "metric_time"])):
            tag = f"10_mf_explain_{i:02d}_{name}" + ("" if not extra else "_metric_time")
            rc, so, se = R.run(tag, ["mf", "query", "--metrics", name, *extra, "--explain"], proj, timeout=300)
            mm = re.search(r"^(SELECT|WITH)\b.*", so, re.S | re.M)
            ok = bool(mm) and rc == 0 and "ERROR" not in so[:mm.start()]
            att = {"group_by": extra[1] if extra else None, "exit": rc, "sql_found": bool(mm), "log_tag": tag}
            if ok:
                sqlf = sqldir / f"{name}{'' if not extra else '__metric_time'}.sql"
                sqlf.write_text(mm.group(0).rstrip() + "\n")
                att["sql_file"] = str(sqlf.relative_to(out))
                att["sql_sha256"] = sha256(sqlf)
            else:
                err = [l for l in (so + "\n" + ANSI.sub("", se)).splitlines() if l.strip() and "Initiating" not in l]
                k = next((n for n, l in enumerate(err) if "ERROR" in l), max(len(err) - 8, 0))
                att["error_message"] = err[k:k + 10]
            attempts.append(att)
            if ok:
                break
        rec["explain_attempts"] = attempts
        rec["compiled_sql_status"] = ("verified_ungrouped" if attempts[0].get("sql_file")
                                      else "verified_metric_time_only" if len(attempts) > 1 and attempts[1].get("sql_file")
                                      else "failed")
        rows.append(rec)
    for f in ("manifest.json", "semantic_manifest.json"):
        meta[f"sha256_{f}_after_explain"] = sha256(proj / "target" / f)
    # warehouse inventory after explain: shows whether any relation was created or needed
    db = out / "dev.duckdb"
    meta["duckdb_exists_after_explain"] = db.exists()
    if db.exists():
        meta["duckdb_sha256"], meta["duckdb_bytes"] = sha256(db), db.stat().st_size
        R.run("20_duckdb_inventory", [f"{a.venv}/bin/python", "-c",
              "import duckdb,json,sys; c=duckdb.connect(sys.argv[1], read_only=True); "
              "print(json.dumps(c.execute('select table_catalog, table_schema, table_name, table_type "
              "from information_schema.tables order by 1,2,3').fetchall()))", str(db)], out)
    finish(out, meta, R, rows, a)


def finish(out, meta, R, rows, a):
    meta["run_end_utc"] = utc()
    meta["commands"] = R.commands
    (out / "run_metadata.json").write_text(json.dumps(meta, indent=1))
    (out / "provenance.json").write_text(json.dumps(rows, indent=1))
    with open(out / "provenance.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["metric", "type", "declared_file", "declared_lines", "input_measures", "owner_semantic_models",
                    "all_measures_single_owner", "manifest_depends_on", "compiled_sql_status", "sql_file", "sql_sha256"])
        for r in rows:
            ok = next((x for x in r["explain_attempts"] if x.get("sql_file")), {})
            w.writerow([r["metric"], r["type"], r["declared_file"],
                        "-".join(map(str, r["declared_span_text_located"])) if r["declared_span_text_located"] else "",
                        ";".join(m["measure"] for m in r["input_measures"]),
                        ";".join(sorted({o["semantic_model"] for m in r["input_measures"] for o in m["owners"]})),
                        all(m["owner_count"] == 1 for m in r["input_measures"]),
                        ";".join(r["manifest_depends_on"] or []), r["compiled_sql_status"],
                        ok.get("sql_file", ""), ok.get("sql_sha256", "")])
    # bundle: copy adapter script, write SHA256SUMS excluding itself, zip
    shutil.copy(__file__, out / "inputs" / "run_adapter_v2.py")
    for d in (Path("project") / (a.project_subdir or "") / "logs",):
        if (out / d).exists():
            shutil.copytree(out / d, out / "logs" / "dbt_project_logs", dirs_exist_ok=True)
    include = ["run_metadata.json", "provenance.json", "provenance.csv", "inputs", "logs", "manifests", "generated_sql", "report.md", "dev.duckdb"]
    files = sorted(p for inc in include for p in ([out / inc] if (out / inc).is_file() else (out / inc).rglob("*"))
                   if p.is_file())
    sums = "".join(f"{sha256(p)}  ./{p.relative_to(out)}\n" for p in files)
    (out / "SHA256SUMS").write_text(sums)
    print(json.dumps({"out": str(out), "files": len(files)}))


if __name__ == "__main__":
    main()
