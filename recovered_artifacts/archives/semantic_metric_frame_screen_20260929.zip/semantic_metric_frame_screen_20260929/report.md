# Declared-metric cohort screen: bounded public frame (2026-09-29)

**Scope.** This is an AI-run technical screen under `semantic_metric_frame_precommit_20260929.json` (SHA-256 `911ccb677943d4fe6e561e4d4d24d437842e25b3fbb265af89e6d98dde5b1623`, verified before any request).
- It contains no pair comparison, pair draw, value execution, method prediction, human worksheet or relationship label.
- It is technical evidence that needs verification. It is not a human reference judgment.
- The frozen adapter `run_adapter.py` is unchanged: SHA-256 `7b90ef37dfb1cce9c0a15f211ef89fb56106a0f1eb8817ed0ae405ad05ce09fe`, checked before and after.
- The original 62-row queue was not touched.

**Run by:** Claude (AI assistant) in the user's dev container, with unauthenticated GitHub requests only.
**Window:** 2026-09-29, 21:34:37Z–21:41:08Z (UTC).

## 1. Stage 1: metadata capture (complete before any source was opened)

| Query | HTTP | `total_count` | `incomplete_results` | Items on page 1 |
| --- | --- | --- | --- | --- |
| `"dbt semantic layer" in:name,description,topics is:public archived:false` | 200 | 91 | false | 91 |
| `metricflow in:name,description,topics is:public archived:false` | 200 | **201** | false | 100 |
| `topic:dbt topic:semantic-layer is:public archived:false` | 200 | 69 | false | 69 |

The precommit fixes `page: 1`, `per_page: 100`, so **101 results of query 2 lie outside the frame**. This is a property of the precommitted bounded frame, not a failed page. No further page was requested.

The raw bodies, headers, byte lengths and SHA-256 values are in `run1/raw/` and `run1/manifest.json`.

| Step | Count |
| --- | --- |
| Raw items (3 pages) | 260 |
| Duplicates by numeric ID | 22 |
| Unique repositories | 238 |
| Excluded by the metadata filter | 153, all for licence. Some rows had more than one reason; one of these was also a template. |
| Excluded licence values | none/`null` 143, `NOASSERTION` 6, `Unlicense` 2, `AGPL-3.0` 2 |
| **Passed the filter and hash-sorted** | **85** |
| First 20 pinned (by numeric repository ID) | 20/20 pinned; 0 unavailable |

The full queue is in `run1/queue.json`. It contains every deduplicated candidate with its filter reason, and the 20 pinned commits with their ref-response evidence.

## 2. Stage 2: bounded source screen

The sources were screened in contiguous rank order from pinned-commit codeload tarballs. Each tarball's SHA-256 is recorded in the ledger. The screen **stopped at rank 14, where the third eligible project was found.**

| Rank | Repository @ commit | dbt metric declarations (distinct, enabled, in-project) | Verdict |
| --- | --- | --- | --- |
| 1 | takuyanagai0213/semantic-guard | no dbt project | excluded |
| 2 | KarthikRajashekaran/semantic-view-guard | 0 (only `integration_tests/`) | excluded |
| 3 | vbalalian/estore-analytics | 0 | excluded |
| 4 | sawon1903210/bonnard-cli | no dbt project | excluded |
| 5 | g-latam/metric-flow | no dbt project | excluded |
| 6 | benchouse/semglot | not a dbt project (transpiler test data) | excluded |
| **7** | **orbiane/homelab-data-platform @ `5e8e25d7f79c…`** | **5**, in `dbt_project/models/mart/_metrics.yml:2–40` | **selected** |
| 8 | rj1224/semantic-trust | tool whose dbt projects are all test fixtures | excluded |
| **9** | **rohitndev/AI-Augmented-Executive--Revenue-Intelligence-Platform @ `36ea21e4cf79…`** | **10**, in `dbt/models/semantic/metrics.yml:6–79` | **selected** |
| 10 | galafis/people-analytics-dwh-dbt | 0 | excluded |
| 11 | stefbartieri/semantic-mcp | 0 in `dbt/` (custom contract outside it) | excluded |
| 12 | monospaceai/evaldata | Jaffle-family examples/fixtures plus a vendored third-party fixture | excluded |
| 13 | metric-layer/metric-layer | no dbt project | excluded |
| **14** | **KushPatel29/supply-chain-analytics-dbt @ `04ba76437cf0…`** | **5**, in `models/semantic/semantic_models.yml:37–65` | **selected** |
| 15–16 | (see deviation 1) | 0 each, auto-count only | not screened |
| 17–20 | unopened | — | unopened |

Selected-project details:
- **Licence:** all three selected projects carry an MIT `LICENSE` in the pinned source.
- **Data:** ranks 7 and 9 use synthetic data generated in-repo. Rank 14 uses the author's own seed CSVs.
- **Ancestry and tutorials:** no Jaffle, Sidemantic, GTM or Rill ancestry was found, and no explicit tutorial signal.
- **Threshold:** ranks 7 and 14 meet the five-metric threshold **exactly**.

The exact paths, lines, metric names and reasons are in `screen_ledger.json`.

## 3. Coverage-only adapter run (after selection; frozen adapter, no values)

| Rank | Adapter stage reached | Declared metrics | Generated SQL |
| --- | --- | --- | --- |
| 7 | Stopped before parse: `FileNotFoundError project/dbt_project.yml` (nested project `dbt_project/`) | 5 source-defined | unknown, not zero |
| 9 | Stopped before parse, same cause (nested project `dbt/`); Snowflake-targeted SQL | 10 source-defined | unknown, not zero |
| 14 | deps 0, parse 0, 5 explains all exit 0 | 5 | 5/5 ungrouped. All bind to the `orders` semantic model. |

For rank 14, the details of the run in `adapter_rank14/` are:

| Item | Value |
| --- | --- |
| Tooling | `dbt-core 1.12.5`, DuckDB |
| Dependencies | `dbt deps` resolved `dbt_utils` 1.4.1 |
| Invocation ID | `7653bee5-3679-4187-b862-ffda266cc4da` |
| Bundle checksums | its own `SHA256SUMS` |

## 4. Deviations and limits (please verify)

1. **Ranks 15–16 were auto-counted after the stopping point.** A batch command ran through rank 16 before I closed rank 14 by hand. Both show 0 declarations. They received no manual review and cannot affect the selection. They are recorded as `not_screened_after_stop`.
2. **The counter first overcounted.** Its first version counted YAML outside the dbt project, which gave rank 9 42 declarations and rank 11 6. It was corrected so that only YAML inside a non-package dbt project directory counts, and all of ranks 1–16 were recounted from fresh downloads with the corrected script. No verdict was made on the first counts.
3. **Adapter invocation error on rank 14.** My first adapter call used a relative `--out` path, so deps and parse failed with "project-dir does not exist". This was an operator error, not a project failure. That run is kept as `adapter_rank14_ATTEMPT1_relative_out_invocation_error/`. The rerun with an absolute path is the reported one.
4. **The family rule rests on inferred inputs.** I did not have `semantic_metric_cohort_reset_20260929.md`, so I took the family list from outline §5: Jaffle/Sidemantic, GTM, Rill, and the two broad-frame projects. Verify it against the reset document.
5. **Judgment calls to verify:**
   - Excluding tool repositories whose dbt projects are only test fixtures (ranks 8 and 12). This could also be read as "explicit example-only".
   - Treating rank 9 as a portfolio project rather than a tutorial.
6. **Two of the three sit on the threshold.** Ranks 7 and 14 have exactly 5 metrics, and all 5 of rank 14's bind to a single semantic model. Within-project pair variety will be small: 10 unordered pairs each for ranks 7 and 14, and 45 for rank 9.
7. **Two of three can't run under the frozen adapter** because their projects are nested. Supporting them needs a separately versioned adapter, which this task did not make.
8. This frame supplied three projects. It says nothing about how common Semantic Layer adoption is in general.

## 5. Reproduce

```bash
sha256sum precommit/semantic_metric_frame_precommit_20260929.json   # 911ccb67…
env -i PATH=/usr/bin:/bin HOME=$PWD python3 code/stage1_enumerate.py --precommit precommit/semantic_metric_frame_precommit_20260929.json --out run_new
python3 code/stage2_screen.py --queue run_new/queue.json --out screen_new --through-rank 14
# adapter (needs a clone of each selected repo and a dbt-core 1.12.5 + dbt-duckdb + dbt-metricflow venv):
env -i PATH=/usr/bin:/bin HOME=$PWD python3 run_adapter.py --repo /abs/clone --commit <sha> --out /abs/fresh_dir --venv /abs/venv
```

Tools: Python 3.12.3, PyYAML 6.0.3, curl 8.5.0. Script SHA-256 values: `stage1_enumerate.py` `9b284588…302c`, `stage2_screen.py` `ade59dac…29f9`. GitHub search results change over time, so a rerun will not reproduce the same queue. The raw responses in `run1/raw/` are the record.
