#!/usr/bin/env python3
"""Stage 1 of the declared-metric frame: metadata capture, filter, hash sort, pin first 20.

Implements semantic_metric_frame_precommit_20260929.json (SHA-256 911ccb67...5b1623) exactly.
Unauthenticated GitHub REST requests only. Opens no README, YAML, SQL or tree.
Usage: stage1_enumerate.py --precommit precommit.json --out <fresh dir>
"""
import argparse, hashlib, json, subprocess, sys, time, urllib.parse
from datetime import datetime, timezone
from pathlib import Path

EXPECTED_PRECOMMIT = "911ccb677943d4fe6e561e4d4d24d437842e25b3fbb265af89e6d98dde5b1623"


def utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha(b):
    return hashlib.sha256(b).hexdigest()


def fetch(url, api_version, stem, raw):
    """GET with curl; save raw body and headers; return a record plus parsed JSON (or None)."""
    body, hdr = raw / f"{stem}.body.json", raw / f"{stem}.headers.txt"
    start = utc()
    p = subprocess.run(["curl", "-sS", "-D", str(hdr), "-o", str(body), "-w", "%{http_code}",
                        "-H", "Accept: application/vnd.github+json",
                        "-H", f"X-GitHub-Api-Version: {api_version}",
                        "-H", "User-Agent: metric-frame-screen", url],
                       capture_output=True, text=True)
    rec = {"url": url, "request_start_utc": start, "request_end_utc": utc(), "curl_exit": p.returncode,
           "curl_stderr": p.stderr.strip(), "http_status": int(p.stdout) if p.stdout.isdigit() else None,
           "body_file": f"raw/{body.name}", "headers_file": f"raw/{hdr.name}"}
    data = None
    for k, f in (("body", body), ("headers", hdr)):
        b = f.read_bytes() if f.exists() else b""
        rec[f"{k}_bytes"], rec[f"{k}_sha256"] = len(b), sha(b)
    if body.exists():
        try:
            data = json.loads(body.read_bytes())
        except json.JSONDecodeError:
            pass
    return rec, data


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--precommit", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    pc_bytes = Path(a.precommit).read_bytes()
    if sha(pc_bytes) != EXPECTED_PRECOMMIT:
        sys.exit(f"precommit hash mismatch: {sha(pc_bytes)}")
    pc = json.loads(pc_bytes)
    out = Path(a.out)
    if out.exists():
        sys.exit("--out exists; use a fresh directory")
    raw = out / "raw"
    raw.mkdir(parents=True)
    s, flt = pc["search"], pc["metadata_filter_before_hash_sort"]
    manifest = {"run_start_utc": utc(), "precommit_sha256": EXPECTED_PRECOMMIT, "authentication": "none",
                "script_sha256": sha(Path(__file__).read_bytes()), "search_pages": [], "ref_attempts": []}

    # 1. search pages, in order; stop on any non-200 or incomplete page
    items_by_query = []
    for qi, q in enumerate(s["queries_in_order"], 1):
        params = {"q": q, **{k: str(v) for k, v in s["parameters_per_query"].items()}}
        url = s["endpoint"] + "?" + urllib.parse.urlencode(params)
        rec, data = fetch(url, s["github_api_version"], f"search_q{qi}_p1", raw)
        rec.update({"query_index": qi, "query": q, "params": params})
        if isinstance(data, dict):
            rec["total_count"] = data.get("total_count")
            rec["incomplete_results"] = data.get("incomplete_results")
            rec["items_returned"] = len(data.get("items", []))
            # a single page cannot cover more than per_page results; record, don't page further (precommit: page 1)
            rec["page_covers_all_results"] = rec["total_count"] is not None and rec["total_count"] <= s["parameters_per_query"]["per_page"]
        manifest["search_pages"].append(rec)
        if rec["http_status"] != 200 or not isinstance(data, dict) or data.get("incomplete_results") is not False:
            manifest["stopped"] = f"query {qi}: non-200 or incomplete search page"
            (out / "manifest.json").write_text(json.dumps(manifest, indent=1) + "\n")
            sys.exit(manifest["stopped"])
        items_by_query.append((qi, data["items"]))
        time.sleep(7)  # unauthenticated search limit is 10/min

    # 2. filter, dedup by numeric id, hash sort
    allow = set(flt["recognized_license_spdx_allowlist"])
    seen, candidates, counts = {}, [], {"raw_items": 0, "duplicates": 0, "excluded": {}}
    for qi, items in items_by_query:
        for it in items:
            counts["raw_items"] += 1
            rid = it["id"]
            if rid in seen:
                seen[rid]["query_hits"].append(qi)
                counts["duplicates"] += 1
                continue
            lic = (it.get("license") or {}).get("spdx_id")
            reasons = []
            if it.get("private") is not False: reasons.append("not_public")
            if it.get("fork") is not False: reasons.append("fork")
            if it.get("archived") is not False: reasons.append("archived")
            if it.get("is_template") is not False: reasons.append("template")
            if it.get("mirror_url") is not None: reasons.append("mirror")
            if lic not in allow: reasons.append(f"license_not_in_allowlist:{lic}")
            row = {"repository_id": rid, "full_name": it["full_name"], "html_url": it["html_url"],
                   "default_branch": it.get("default_branch"), "license_spdx_metadata": lic,
                   "fork": it.get("fork"), "archived": it.get("archived"), "is_template": it.get("is_template"),
                   "mirror_url": it.get("mirror_url"), "pushed_at": it.get("pushed_at"),
                   "query_hits": [qi], "id_sha256": sha(str(rid).encode("utf-8")),
                   "metadata_filter": "pass" if not reasons else "excluded", "exclusion_reasons": reasons}
            seen[rid] = row
            candidates.append(row)
            for r in reasons:
                key = r.split(":")[0]
                counts["excluded"][key] = counts["excluded"].get(key, 0) + 1
    passed = sorted((c for c in candidates if c["metadata_filter"] == "pass"),
                    key=lambda c: (c["id_sha256"], c["repository_id"]))
    for i, c in enumerate(passed, 1):
        c["rank"] = i
    counts.update({"unique_repositories": len(candidates), "passed_filter": len(passed)})

    # 3. pin the first 20 (default-branch ref by numeric id, so renames can't redirect)
    prefix = passed[:pc["pinned_prefix_size"]]
    for c in prefix:
        br = c["default_branch"]
        url = f"https://api.github.com/repositories/{c['repository_id']}/git/ref/heads/{urllib.parse.quote(br, safe='')}"
        rec, data = fetch(url, s["github_api_version"], f"ref_rank{c['rank']:02d}_{c['repository_id']}", raw)
        rec.update({"rank": c["rank"], "repository_id": c["repository_id"]})
        if rec["http_status"] == 200 and isinstance(data, dict) and (data.get("object") or {}).get("type") == "commit":
            c["pinned_commit"], c["pin_status"] = data["object"]["sha"], "pinned"
        else:
            c["pinned_commit"], c["pin_status"] = None, f"unavailable:http_{rec['http_status']}"
        c["ref_evidence"] = rec["body_file"]
        manifest["ref_attempts"].append(rec)
        time.sleep(1)

    manifest.update({"run_end_utc": utc(), "counts": counts,
                     "prefix_size": len(prefix), "prefix_pinned": sum(c["pin_status"] == "pinned" for c in prefix)})
    queue = {"precommit_sha256": EXPECTED_PRECOMMIT, "sort_rule": pc["sort_rule"], "counts": counts,
             "ranked_passed": passed, "excluded": [c for c in candidates if c["metadata_filter"] != "pass"]}
    (out / "queue.json").write_text(json.dumps(queue, indent=1) + "\n")
    (out / "manifest.json").write_text(json.dumps(manifest, indent=1) + "\n")
    print(json.dumps({"counts": counts, "prefix_pinned": manifest["prefix_pinned"]}, indent=1))


if __name__ == "__main__":
    main()
