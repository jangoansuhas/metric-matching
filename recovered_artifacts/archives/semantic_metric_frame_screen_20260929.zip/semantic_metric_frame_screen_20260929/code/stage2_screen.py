#!/usr/bin/env python3
"""Stage 2 of the declared-metric frame: bounded source screen of the pinned prefix, in rank order.

For each rank (contiguous, starting at 1) it downloads the pinned-commit tarball from codeload
(no auth), records its SHA-256, and counts source-defined dbt Semantic Layer metric declarations:
  * legacy top-level `metrics:` list items;
  * dbt v1.12+ colocated `models[].metrics:` items on a model that declares `semantic_model:`.
Semantic models, measures, SQL aggregates, disabled metrics and anything under dbt_packages/,
dbt_modules/ or target/ are not counted. YAML that fails to parse is listed as unresolved, never zero.
The script only counts; licence, family/tutorial and final verdicts are recorded by hand in the ledger.

Usage: stage2_screen.py --queue run1/queue.json --out screen --through-rank N
"""
import argparse, hashlib, io, json, re, subprocess, sys, tarfile
from pathlib import Path
import yaml

SKIP_DIRS = {"dbt_packages", "dbt_modules", "target", "node_modules", ".git", "logs"}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def items_with_lines(path):
    """Return (doc, error). doc is composed with line numbers attached to mapping nodes."""
    text = path.read_text(errors="replace")
    try:
        node = yaml.compose(text, Loader=yaml.SafeLoader)
    except yaml.YAMLError as e:
        return None, str(e).splitlines()[0]
    return node, None


def mget(node, key):
    if isinstance(node, yaml.MappingNode):
        for k, v in node.value:
            if isinstance(k, yaml.ScalarNode) and k.value == key:
                return v
    return None


def scalar(node):
    return node.value if isinstance(node, yaml.ScalarNode) else None


def disabled(item):
    cfg = mget(item, "config")
    en = mget(cfg, "enabled") if cfg is not None else None
    if en is None:
        en = mget(item, "enabled")
    v = scalar(en)
    return v is not None and v.strip().lower() in ("false", "no", "off")


def metric_rows(node, rel):
    rows = []
    def add(item, kind, owner=None):
        name = scalar(mget(item, "name"))
        rows.append({"file": rel, "line": item.start_mark.line + 1, "end_line": item.end_mark.line + 1,
                     "name": name, "kind": kind, "type": scalar(mget(item, "type")),
                     "owner_model": owner, "disabled": disabled(item)})
    top = mget(node, "metrics")
    if isinstance(top, yaml.SequenceNode):
        for it in top.value:
            if isinstance(it, yaml.MappingNode):
                add(it, "top_level_metrics")
    models = mget(node, "models")
    if isinstance(models, yaml.SequenceNode):
        for m in models.value:
            ms = mget(m, "metrics")
            if isinstance(ms, yaml.SequenceNode):
                attached = mget(m, "semantic_model") is not None
                for it in ms.value:
                    if isinstance(it, yaml.MappingNode):
                        add(it, "model_colocated_metrics" if attached else "model_metrics_without_semantic_model",
                            scalar(mget(m, "name")))
    return rows


def screen(c, out):
    d = out / f"rank_{c['rank']:02d}"
    owner, repo = c["full_name"].split("/")
    url = f"https://codeload.github.com/{owner}/{repo}/tar.gz/{c['pinned_commit']}"
    tgz = out / f"rank_{c['rank']:02d}.tar.gz"
    p = subprocess.run(["curl", "-sS", "-o", str(tgz), "-w", "%{http_code}", url], capture_output=True, text=True)
    rec = {"rank": c["rank"], "repository_id": c["repository_id"], "full_name": c["full_name"],
           "pinned_commit": c["pinned_commit"], "tarball_url": url, "tarball_http": p.stdout}
    if p.stdout != "200":
        rec["screen_status"] = "tarball_unavailable"
        return rec
    b = tgz.read_bytes()
    rec["tarball_sha256"], rec["tarball_bytes"] = sha(b), len(b)
    d.mkdir()
    with tarfile.open(fileobj=io.BytesIO(b)) as t:
        t.extractall(d, filter="data")
    root = next(d.iterdir())
    files = sorted(str(f.relative_to(root)) for f in root.rglob("*") if f.is_file())
    rec["file_count"] = len(files)
    rec["root_license_files"] = [f for f in files if re.match(r"(?i)^(licen[cs]e|copying)(\.|$)", f)]
    rec["license_first_lines"] = {f: (root / f).read_text(errors="replace").strip().splitlines()[:2] for f in rec["root_license_files"]}
    rec["dbt_projects"] = [f for f in files if Path(f).name == "dbt_project.yml"
                           and not SKIP_DIRS & set(Path(f).parts)]
    rows, unresolved, sm_files = [], [], 0
    for f in files:
        parts = set(Path(f).parts)
        if SKIP_DIRS & parts or not f.endswith((".yml", ".yaml")):
            continue
        node, err = items_with_lines(root / f)
        if err:
            if re.search(r"(?m)^\s*(metrics|semantic_models)\s*:", (root / f).read_text(errors="replace")):
                unresolved.append({"file": f, "error": err})
            continue
        if node is None:
            continue
        if mget(node, "semantic_models") is not None:
            sm_files += 1
        rows.extend(metric_rows(node, f))
    rec["files_with_semantic_models"] = sm_files
    rec["metric_declarations"] = rows
    rec["unresolved_yaml_with_metric_keys"] = unresolved
    # project-owned: the YAML must sit inside a (non-package) dbt project directory
    proj_dirs = [str(Path(f).parent) for f in rec["dbt_projects"]]
    for r in rows:
        r["in_dbt_project"] = next((pd for pd in proj_dirs if pd == "." or r["file"].startswith(pd + "/")), None)
    unresolved[:] = [u for u in unresolved if any(pd == "." or u["file"].startswith(pd + "/") for pd in proj_dirs)]
    enabled = [r for r in rows if r["in_dbt_project"] and not r["disabled"]
               and r["kind"] != "model_metrics_without_semantic_model"]
    rec["per_project_distinct_enabled"] = {pd: len({r["name"] for r in enabled if r["in_dbt_project"] == pd and r["name"]})
                                           for pd in proj_dirs}
    rec["max_project_distinct_enabled"] = max(rec["per_project_distinct_enabled"].values(), default=0)
    rec["screen_status"] = "counted"
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--queue", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--through-rank", type=int, required=True)
    a = ap.parse_args()
    q = json.load(open(a.queue))
    out = Path(a.out)
    out.mkdir(exist_ok=True)
    for c in q["ranked_passed"][:a.through_rank]:
        f = out / f"count_rank_{c['rank']:02d}.json"
        if f.exists():
            continue
        if c.get("pin_status") != "pinned":
            f.write_text(json.dumps({"rank": c["rank"], "screen_status": "unpinned_not_opened"}, indent=1) + "\n")
            continue
        rec = screen(c, out)
        f.write_text(json.dumps(rec, indent=1) + "\n")
        print(c["rank"], c["full_name"], rec.get("per_project_distinct_enabled"),
              "unresolved:", len(rec.get("unresolved_yaml_with_metric_keys", [])),
              "license:", rec.get("root_license_files"))


if __name__ == "__main__":
    main()
