
    
    



select supply_uuid
from "jaffle_dev"."main"."stg_supplies"
where supply_uuid is null


