
    
    



select order_item_id
from "jaffle_dev"."main"."order_items"
where order_item_id is null


