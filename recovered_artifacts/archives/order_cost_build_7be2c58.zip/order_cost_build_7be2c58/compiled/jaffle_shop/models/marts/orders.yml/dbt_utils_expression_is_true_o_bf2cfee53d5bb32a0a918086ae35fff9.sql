



select
    1
from "jaffle_dev"."main"."orders"

where not(order_total = subtotal + tax_paid)

