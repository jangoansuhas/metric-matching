
    
    



select order_id
from "jaffle_dev"."main"."orders"
where order_id is null


