SELECT
  SUM(order_cost) AS order_cost
FROM "jaffle_dev"."main"."orders" orders_src_10000
