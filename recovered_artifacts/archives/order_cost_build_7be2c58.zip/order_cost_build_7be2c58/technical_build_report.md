# Technical build report: `order_cost` compiled provenance (Jaffle Shop, development only)

**Scope.** This is a technical build to check how metric `order_cost` resolves. It does **not** assign a relationship label to CAL-03, it is **not** human adjudication, and no held-out repository was inspected. Keep it away from the blind CAL-03 reviewer until their worksheet is locked.

**Run by:** Claude (AI assistant) in the user's dev container. **Run window:** 2026-09-28 15:46:54Z – 15:51:17Z (UTC).

## 1. Inputs and environment

| Item | Value |
| --- | --- |
| Repository / commit | `dbt-labs/jaffle-shop` @ `7be2c5838dbdeca8e915d4e46db70e910753d7f6` (`git cat-file -t` → `commit`, in existing clone `/tmp/jaffle-shop`) |
| Export method | `git archive --format=tar <commit> \| tar -x` into fresh `/tmp/jaffle_build_kmqNbx/project`. The export had no `target/`, `dbt_packages/`, or `logs/` directories. The archive tar SHA-256 is `7af86465…f3e88e`. |
| `packages.yml` (original) | SHA-256 `43c2cc277fee0dd4bb0958c711593509b4b30171e8dc04074184ab93d62b2cce` |
| `package-lock.yml` (original) | SHA-256 `a1d44d11c893f4d68e722ef8479bd3c4d2f632202f1ef7bd4ade6a14986b50db` |
| OS | Ubuntu 24.04.5 LTS, Linux 6.10.14-linuxkit, aarch64 (Docker Desktop) |
| Python | 3.12.3, fresh `venv` at `/tmp/jaffle_build_kmqNbx/venv` |
| Installed (pinned) | `dbt-core==1.12.5`, `dbt-duckdb==1.11.0`, `metricflow==0.213.0`, `dbt-metricflow==0.15.0`. Resolved transitively: `dbt-adapters 1.24.5`, `dbt-common 1.39.0`, `duckdb 1.5.6`, `sqlglot 30.20.0`. Full list in `logs/pip_freeze.txt`. |
| `dbt --version` | Core 1.12.5; plugin duckdb 1.11.0 |
| `mf --version` | `mf, version 0.15.0` (the CLI reports the `dbt-metricflow` version; the engine is `metricflow 0.213.0`) |
| Profile | `profiles/profiles.yml`: profile `default`, target `dev`, `type: duckdb`, `path: /tmp/jaffle_build_kmqNbx/jaffle_dev.duckdb`. No credentials, no remote warehouse, no copied profile. |

### Environment isolation deviation (important)

The container's login shell exports company dbt settings: `DBT_WARN_ERROR_OPTIONS={"error":"all",...}`, `DBT_PROFILES_DIR=<company dbt repo path, redacted>`, `DBT_LOOM_CONFIG`, and `DBT_SNOWFLAKE_*`. The first two `dbt deps` attempts inherited `DBT_WARN_ERROR_OPTIONS`, so the "git package pinned to main" warning became a fatal `Compilation Error` (exit 2). Explicit `--profiles-dir` flags were passed, so the company profile was not used.

From that point, every dbt/mf command ran through `run_clean.sh` (`env -i`), which passes only `HOME`, `PATH`, `LANG`, `DBT_PROFILES_DIR` (the temp dir), `DBT_SEND_ANONYMOUS_USAGE_STATS=false`, and `DO_NOT_TRACK=1` (see `logs/clean_env.txt`). No declared dependency was edited.

## 2. Commands, exit codes, timing

| # | Command (all with `--project-dir`/`--profiles-dir` = temp dirs) | Env | Exit | Elapsed | Logs |
| --- | --- | --- | --- | --- | --- |
| 0 | `pip install dbt-core==1.12.5 dbt-duckdb==1.11.0 metricflow==0.213.0 dbt-metricflow==0.15.0` | shell | 0 | 53 s | `pip_install.*` |
| 1 | `dbt deps` | inherited (contaminated) | **2** | unrecorded (`bc` missing) | `dbt_deps.*` |
| 2 | `dbt --debug deps` | inherited (contaminated) | **2** | 4.06 s | `dbt_deps_debug.*` (shows `warn_error_options error='all'`) |
| 3 | `dbt deps` | clean | 0 | 8.76 s | `dbt_deps_clean.*` |
| 4 | `dbt parse --no-partial-parse` | clean | 0 | 6.34 s | `dbt_parse.*` |
| 5 | `mf query --metrics order_cost --explain` (from project root) | clean | 0 | 7.06 s | `mf_explain_1.*` |
| 6 | *Extra, not requested:* `dbt compile --select stg_supplies order_items orders` | clean | 0 | 3.19 s | `dbt_compile_extra.*` |

The `--group-by metric_time` retry was **not run**, because command 5 succeeded without a grouping.

Parse warnings (non-fatal): 8 × `MissingArgumentsPropertyInGenericTestDeprecation` (e.g. `stg_orders.yml`), and "Metric 'cumulative_revenue' … cumulative window and grain semantics cannot be represented" in the OSI document. Neither involves `order_cost`.

## 3. Effective dependency resolution

`dbt deps` ignored the committed lockfile and re-resolved from `packages.yml`, then rewrote `package-lock.yml`. Diff: `logs/package-lock.diff`.

| Package | `packages.yml` (declared) | Original `package-lock.yml` | **Effective installed** (from deps log) |
| --- | --- | --- | --- |
| dbt-labs/dbt_utils | 1.3.3 | 1.1.1 | **1.3.3** |
| godatadriven/dbt_date | 0.17.1 | 0.10.0 | **0.17.1** |
| dbt-audit-helper (git) | `revision: main` | `b8f3a3348ce0ff8afc3aa4b9ade2123b00772473` | **`71817f0a7fa3df9f63adb90db0cf28f7423f720b`** (`main` HEAD at 2026-09-28 15:49Z) |

- New `package-lock.yml` SHA-256: `67ecfc0a7ebdcc03b8e2f38c86d7b283e72c5d58fb9a7de9b4f30aa2a3a01eef` (new `sha1_hash: 171c3fa5…`; old `f2a73967…`). The original is preserved in `original_inputs/`.
- **Reproducibility gap:** `audit_helper` floats on `main`, so a later rerun may install different code. None of the traced `order_cost` artifacts reference audit_helper macros, but I didn't test whether they affect the parse otherwise.
- The `version:` fields inside each installed package's own `dbt_project.yml` (`0.1.0`, `0.5.0`, `0.4.0`) are the packages' internal project versions, not hub versions. `logs/effective_packages.txt` records them only for completeness.

## 4. Fresh artifacts and hashes

Before command 4, `project/target/` did not exist. All artifacts below were written by command 4 at 15:49:31Z. Manifest `invocation_id` is `e4ba80a2-9cf9-4568-aba5-5baf4c4050c9` and `generated_at` is 2026-09-28T15:49:27Z, with `dbt_version 1.12.5` and `adapter_type duckdb`.

| Artifact | SHA-256 | Note |
| --- | --- | --- |
| `manifests/manifest.json` (copied right after parse) | `5df1c7ab51cceffc4c7815753ec16c748aa32b0353fe52dbb41d6f953cca487a` | This is the parse output. Command 6 later rewrote `target/manifest.json` to `ad5dae94…`; that version is **not** the one reported here. |
| `manifests/semantic_manifest.json` | `9700b15b4e19df1d71e39aad78fe30795afdefd2b46bc4a4c2f5c7ee088e0a63` | Unchanged by commands 5 and 6. |
| `order_cost_generated.sql` | `583bc4bbe7b96fa0eff5cd58e24e2f576d4dc5954360916cd19c1812334bf22f` | From command 5 stdout. |
| `compiled/…/stg_supplies.sql`, `order_items.sql`, `orders.sql` (extra) | `0fa0d78a…`, `508b47c1…`, `9ce5ad11…` | From command 6. |

Command 5 did not rewrite either manifest: hashes and mtimes were identical before and after.

## 5. Binding: same-name YAML match vs. resolved binding in fresh artifacts

**Same-name match in YAML (pinned source):**
- `models/marts/order_items.yml:96–101` declares metric `order_cost` (`type: simple`, `type_params.measure: order_cost`, description "Sum of cost for each order item.").
- `models/marts/order_items.yml:70–86`: the `order_item` semantic model has measures `revenue`, `food_revenue`, `drink_revenue`, and `median_revenue`, and **no** `order_cost`.
- `models/marts/orders.yml:119–121` declares measure `order_cost` (`agg: sum`, no `expr`) in the `orders` semantic model (`orders.yml:78–84`, `model: ref('orders')`, default `agg_time_dimension: ordered_at`).

**Resolved binding in the fresh artifacts:**
- `semantic_manifest.json`: metric `order_cost` has `type_params.measure.name = order_cost` and `input_measures = [order_cost]`, with no filter, no `fill_nulls_with`, and `join_to_timespine: false`. Exactly one semantic model declares a measure named `order_cost`: `orders` (`agg: sum`, `expr: null`, node relation `"jaffle_dev"."main"."orders"`). The `order_item` measures list matches the YAML above.
- `manifest.json`: node `metric.jaffle_shop.order_cost` has `original_file_path: models/marts/order_items.yml` and **`depends_on.nodes: ["semantic_model.jaffle_shop.orders"]`**. Node `semantic_model.jaffle_shop.orders` (`models/marts/orders.yml`) depends on `model.jaffle_shop.orders`, which depends on `model.jaffle_shop.stg_orders` and `model.jaffle_shop.order_items`.
- So the fresh parse records a dependency edge from the metric to the `orders` semantic model. That is more than a name coincidence. MetricFlow's own SQL generation (§6) confirms the same binding.

## 6. Generated metric SQL (`mf query --metrics order_cost --explain`)

```sql
SELECT
  SUM(order_cost) AS order_cost
FROM "jaffle_dev"."main"."orders" orders_src_10000
```

**Warehouse connection, based on this run:** `mf` opened a connection to the **local** DuckDB file and ran a connection test (`project/logs/dbt.log`, 15:50:04: "Connection test: OK connection ok"). The file did not exist before command 5; it was created then (12,288 bytes). Afterwards it contained **no tables** (`information_schema.tables` was empty). So in this run:
- a local adapter connection was opened;
- no built tables or data were needed to generate the SQL.

Whether `--explain` can run with **no** connection at all is **unknown**, because I didn't test that.

## 7. Resolved chain: metric → measure → semantic model → source expression

| Step | Evidence (pinned source line numbers; fresh artifact where noted) |
| --- | --- |
| Metric `order_cost` | `models/marts/order_items.yml:96–101`; manifest node `metric.jaffle_shop.order_cost` |
| → measure `order_cost`, `agg: sum`, column `order_cost` (no `expr`) | `models/marts/orders.yml:119–121`; semantic_manifest measure under `orders` |
| → semantic model `orders` on `ref('orders')` | `models/marts/orders.yml:78–84`; manifest `semantic_model.jaffle_shop.orders` → `model.jaffle_shop.orders` |
| → generated metric SQL `SUM(order_cost)` over the `orders` relation | `order_cost_generated.sql` (command 5) |
| → `orders.order_cost = sum(supply_cost)` per `order_id` over `order_items` | `models/marts/orders.sql:15–21, 36–38` (line 20); carried in `compute_booleans` at `:47`; `orders` **left join** `order_items_summary` at `:55–59` |
| → `order_items.supply_cost` = per-`product_id` `sum(supply_cost)` over supplies, left-joined to each item | `models/marts/order_items.sql:28–39` (line 33, `group by 1` at 37), `:53`, `:61–62` |
| → `stg_supplies.supply_cost = cents_to_dollars('cost')` from `source('ecom','raw_supplies')` | `models/staging/stg_supplies.sql:5, 22` |
| → macro expansion on DuckDB: `(cost / 100)::numeric(16, 2)` | `macros/cents_to_dollars.sql:7–9` (`default__`; no `duckdb__` variant); confirmed in compiled `stg_supplies.sql:22` (command 6) |

In the fresh manifest, `raw_code` for `orders`, `order_items`, `stg_supplies`, and `stg_orders` equals the exported file contents with leading and trailing whitespace stripped (`logs/raw_code_check.txt`). The exported `orders.sql` is byte-identical to the pinned Git blob (SHA-256 `a1196f29…`).

## 8. Remaining gaps

1. **No execution.** No seeds were loaded and no models were built or queried, so there are no metric output values. The SQL was generated but never run.
2. **Floating git dependency.** `audit_helper` resolved to `main` @ `71817f0`, not the committed lock's `b8f3a33`. The committed lockfile was stale relative to `packages.yml` and was regenerated.
3. **Engine-specific output.** The generated SQL and macro expansion are for DuckDB only. Other adapters dispatch `cents_to_dollars` differently (`macros/cents_to_dollars.sql:11–21`).
4. **Checksum scheme.** dbt's node `checksum` values (e.g. `orders` → `61e17f8b…`) don't equal the SHA-256 of either the raw or the stripped file. I didn't reproduce dbt's scheme. Content identity is established through `raw_code` instead.
5. **Connection-free explain untested** (see §6).
6. **Isolation deviation.** The inherited-environment failures (commands 1–2) are documented above. Only clean-environment results (commands 3–6) are used.
7. **Grouped queries.** Only the unfiltered, ungrouped query was generated. Time-grouped or dimension-grouped SQL for `order_cost` (for example `metric_time`, which would use `orders.ordered_at`) was not generated.

## 9. ZIP contents

`technical_build_report.md`; `order_cost_generated.sql`; `manifests/manifest.json`, `manifests/semantic_manifest.json` (from the parse); `compiled/` (extra command 6 output); `logs/` (stdout/stderr/exit for every command, `versions.txt`, `pip_freeze.txt`, `clean_env.txt`, `binding_trace.txt`, `raw_code_check.txt`, `package-lock.diff`, `effective_packages.txt`, dbt/mf logs); `inputs/` (original `packages.yml` and `package-lock.yml`, regenerated `package-lock.yml`, `profiles.yml`, `run_clean.sh`); `SHA256SUMS`.
