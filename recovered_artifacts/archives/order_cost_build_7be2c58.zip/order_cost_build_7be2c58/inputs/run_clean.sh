#!/bin/bash
# Run a command with a scrubbed environment: no inherited DBT_* / Snowflake / loom vars.
exec env -i HOME=/tmp/jaffle_build_kmqNbx/home PATH=/tmp/jaffle_build_kmqNbx/venv/bin:/usr/bin:/bin LANG=C.UTF-8 \
  DBT_PROFILES_DIR=/tmp/jaffle_build_kmqNbx/profiles DBT_SEND_ANONYMOUS_USAGE_STATS=false DO_NOT_TRACK=1 "$@"
