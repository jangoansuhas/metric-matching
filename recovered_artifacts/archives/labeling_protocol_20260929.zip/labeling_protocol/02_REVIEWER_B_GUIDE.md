# Reviewer B guide: labelling metric pairs

Thank you for helping. This guide is everything you need. Please read it all once before you start.

In every file, you are **Reviewer B**. Don't write your real name anywhere.

---

## 1. What you're doing

A "metric" in a dbt project is a named business number, like `revenue` or `order_count`, declared in a YAML file. Many projects have metrics that sound alike but may or may not compute the same number.

For each **pair** of metrics in your packet, you decide two things:

1. **Relationship label:** how the two metrics relate (§4).
2. **Evidence status:** whether the public source files are enough to be sure (§5).

You'll write down which files and lines support your decision. There are no trick questions. We want your honest professional judgment, including "I can't tell".

## 2. Ground rules

1. **No AI tools at any point.** That means no ChatGPT, Claude, Copilot, Gemini, or AI answer boxes in search results. If one pops up, don't read it.
2. **Work alone.** Don't discuss specific pairs with anyone, including the coordinator (Reviewer A), until you've sent in your finished worksheet.
3. **Asking about the rules is fine.** You can ask what a word in this guide means, or how to open a file. Send the question in writing. The answer will go to everyone in writing, so every reviewer is working from the same rules.
4. **Use only these sources:**
   - the files at the exact commit given in your packet, through the links provided;
   - the official dbt documentation at `docs.getdbt.com`.
5. **Don't change answers after you send them.** If you later spot a mistake, send a separate note and leave the original file as it was.

## 3. How to review one pair

1. Open both metric declarations using the links in the packet. Each link opens the exact lines at the pinned commit.
2. Follow each metric back to what it is actually built from:
   - **Measure:** the aggregation, e.g. `SUM` of some column, with its `agg` and `expr`.
   - **Semantic model:** which model or table it reads from, and at what grain (one row per order, per customer, per item...).
   - **Filters:** any `filter:` on the metric or measure.
   - **Time behaviour:** cumulative windows, offsets like "previous month", and the time dimension used.
   - **The SQL model:** the underlying SQL model, if you need to see how a column is computed.
3. Ask yourself: **if someone swapped one metric for the other in a report, would they get the same number?** Consider:
   - the single overall total;
   - the number by day, month, or year;
   - the number broken down by any dimension both metrics share, such as customer or location.

   `[CONFIRM]`: this is the comparison scope for the study.
4. Pick a label (§4) and an evidence status (§5). Write down the exact files and line numbers you relied on.
5. Record your minutes on each pair. Rough numbers are fine.

## 4. Relationship labels (pick exactly one, or leave blank)

`[CONFIRM]`: wording must match the paper's taxonomy exactly.

| Label | Use it when | Example |
| --- | --- | --- |
| `direct_equivalent` | They compute the **same number** for every comparison scope in §3 step 3. The names or SQL text may differ. | `total_sales` and `gross_sales`, both `SUM(amount)` over the same table, same filters, same time dimension |
| `cross_grain_equivalent` | They measure the same quantity, but at **different grains**, and one rolls up exactly to the other (the rollup is visible in the sources). | Account-level `lifetime_bookings`, which sums exactly to invoice-level `bookings` |
| `temporal_or_scope_variant` | Same underlying quantity, but one is restricted or shifted: an extra filter, a different time window, cumulative vs per-period, previous-period offset, or a subset of the population. | `sales` vs `sales_eu` (EU rows only); `sales` vs `sales_ytd` |
| `conflicting_definition` | They present themselves as the **same business concept** (same or near-same name or description), but the definitions compute different numbers. The mismatch isn't explained anywhere. | Two metrics both called "net revenue", one after refunds and one before |
| `related` | Different quantities, but with a **documented connection**: one is a component of the other, one is derived from the other, or they combine in a formula. | `sales` and `margin = sales - cogs` |
| `non_match` | Different quantities with **no documented connection** beyond living in the same project or table. | `shipping_cost` vs `active_users` |
| *(blank)* | You can't choose a label from the evidence available. Mark the evidence status `needs_review` and explain what's missing. | |

If two labels seem to fit:
- **Filter or time window vs quantity.** If the difference is only a filter or a time window, use `temporal_or_scope_variant`. If the two measure genuinely different quantities, use `related`.
- **`direct_equivalent` vs `temporal_or_scope_variant`.** If they are identical only at *some* scopes, e.g. the same overall total but different by month, the answer is **not** `direct_equivalent`. Use `temporal_or_scope_variant` and say at which scope they diverge.

## 5. Evidence status (pick one)

| Status | Use it when |
| --- | --- |
| `sufficient` | The cited files settle your label. Any remaining unknowns **wouldn't change** it. |
| `needs_review` | Something you couldn't see **could change** your label. Examples: a macro you couldn't resolve, a column computed somewhere you couldn't find, or data you'd need to see. |

## 6. Rulings on common questions

- **Running code.** Don't run anything, including `dbt parse`. Read the files only.
- **Broken links or wrong line numbers.** Stop and tell the coordinator. Don't guess.
- **Anything else unclear.** Choose the answer you think is best, and record your uncertainty in the Notes section. Rulings made after the practice round will reach you in writing, through the Q&A log.

## 7. Order of work

1. **Practice round.** You'll first get a short practice packet (3 pairs). Do it exactly as described above and send your worksheet. Practice answers aren't scored. They help sort out confusing wording in this guide. After the practice round, you may discuss the *rules* (not the pairs) with the coordinator.
2. **Main round.** You'll get one or more packets of pairs with codes like `P-01`. Label them in the order given.
3. **Sending your worksheet.** When you finish a packet:
   - email your worksheet to the coordinator, so the email timestamp records when it was done;
   - keep a copy yourself;
   - don't open or change your copy after sending.

## 8. Worksheet template (copy one per packet)

```
# Reviewer B worksheet

Packet ID: ________   Packet SHA-256 (from README): ________
Date and time zone: ________
SQL/dbt experience (one line, e.g. "5 yrs SQL, 2 yrs dbt"): ________
Start time: ________   End time: ________   Active minutes (excluding breaks): ________

| Pair | Relationship label (or blank) | Evidence status | Files and exact lines supporting decision | Missing evidence, if any | Scope where they differ / conditions for equality, if any | Minutes |
| --- | --- | --- | --- | --- | --- | --- |
| P-01 | | | | | | |
| P-02 | | | | | | |

Notes on unclear rules, broken links, or access problems:
-

Declaration: I completed this worksheet independently, using only the pinned
sources and official dbt documentation. I did not use any AI tool, and I did
not discuss these pairs with anyone before sending it.
Reviewer code: Reviewer B        Date: ________
```

Thank you. Your careful, independent judgment is what makes this study credible.
