# Adjudicator guide: resolving reviewer disagreements

Thank you for agreeing to adjudicate. Two reviewers, **A** and **B**, have each independently labelled the same metric pairs. Your job is to produce the **final label** for each pair. You will focus on the pairs where they disagree.

In every file, you are **Adjudicator C**. Don't write your real name anywhere.

---

## 1. Eligibility (please confirm before starting)

You must:

- not be Reviewer A or Reviewer B, and not have helped write the paper or build its method;
- not have seen any automated or AI output for these pairs, including method results, baselines, and chatbot analyses;
- be able to read dbt YAML and SQL.

If any of these isn't true, tell the coordinator and stop.

## 2. Ground rules

1. **No AI tools** at any point: no ChatGPT, Claude, Copilot, or AI search summaries.
2. **Sources:**
   - the pinned files, through the packet links;
   - the official dbt docs at `docs.getdbt.com`;
   - the reviewers' locked worksheets;
   - the Q&A log of written rulings.

   Use nothing else. Don't run code.
3. **Use the same rulebook as the reviewers.** Apply the label and evidence definitions in `02_REVIEWER_B_GUIDE.md` §4–§5, plus any written rulings in the Q&A log. Don't invent new categories.
4. **Treat both reviewers equally.** Reviewer A is the paper's first author. That must give A's answer **no extra weight**. Judge only the evidence.
5. **Questions to reviewers go in writing, to both of them.** If you need a reviewer to clarify something they wrote, send the same written question to both A and B, and keep their written replies. Don't hold a live discussion with only one reviewer.

## 3. What you receive

- the three guides;
- the pair packet and its SHA-256;
- A's and B's **locked** worksheets (the coordinator will give their SHA-256 values);
- the Q&A log.

Check that the SHA-256 values match what the coordinator logged. If they don't, stop and report it.

## 4. Procedure for each pair

| Case | What you do |
| --- | --- |
| **Full agreement** (same label **and** same evidence status) | Accept it. Skim the cited lines. Override only if you find a clear factual error, e.g. a cited line that doesn't say what's claimed, and explain the override. |
| **Same label, different evidence status** | Read the "missing evidence" notes. Decide whether the gap could change the label (`needs_review`) or not (`sufficient`). |
| **Different labels** | Review the pair yourself from the sources (as in B's guide §3), then read both reviewers' reasoning. Pick A's label, B's label, or a third label if the evidence clearly supports it. Explain the decisive evidence. |
| **One or both left the label blank** | Decide whether the sources support a label. If they don't, leave it blank with `needs_review`. |
| **Truly can't decide** | Mark it **`unresolved`** and explain why. Unresolved pairs are reported separately in the paper. That's an honest outcome, not a failure. |

Also:
- For each disagreement, give a **root cause**:
  - `rubric_wording`: the definitions were ambiguous;
  - `missed_evidence`: one reviewer missed a relevant line;
  - `scope`: they compared at different scopes (total vs by-month vs by-dimension);
  - `judgment`: both readings are defensible;
  - `other`.
- If a disagreement comes from unclear rubric wording, say so. The paper reports these.

## 5. Decision record (fill one per packet)

```
# Adjudicator C decision record

Packet ID: ________   Packet SHA-256: ________
A worksheet SHA-256: ________   B worksheet SHA-256: ________   (checked: yes / no)
Date and time zone: ________   Active minutes: ________

| Pair | A label / evidence | B label / evidence | Final label | Final evidence | Case (agree / evidence-only / different / blank / unresolved) | Root cause (if disagreement) | Decisive files and lines | Rationale (1–3 sentences) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| P-01 | | | | | | | | |

Written clarification questions sent to both reviewers (date, question, both replies):
-

Rubric problems observed:
-

Declaration: I am neither Reviewer A nor B. I did not see any automated or AI
output for these pairs, and I did not use AI tools. I applied the shared rubric
and gave neither reviewer's answer extra weight.
Code: Adjudicator C        Date: ________
```

## 6. When you're done

- Email the decision record to the coordinator and keep a copy. Don't change it after sending. If you need a correction, send a separate dated note.
- Your final labels are the study's gold standard. The coordinator will not edit them.

## 7. Practice pairs (if asked)

You may be asked to settle the practice pair **CAL-03**. Handle it with this same procedure, using the three locked answers you're given. Your result is recorded as a **development calibration outcome**. It is not gold data and isn't scored in the paper.
