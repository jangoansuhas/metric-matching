# Human labelling protocol: your guide (author, Reviewer A, coordinator)

You have two roles:

- **Coordinator.** You prepare the packets, lock the files, and keep the log.
- **Reviewer A.** You label every pair independently, like Reviewer B.

These roles pull against each other. Most of the rules below are there so that being the coordinator doesn't leak into your labels.

> **Update, 2026-09-29.**
> - The reviewer-facing materials now live in the private repo `metric-review-materials`; local copy `/tmp/reviewer_repo`.
> - Those materials **supersede** `02_REVIEWER_B_GUIDE.md` and `03_ADJUDICATOR_GUIDE.md`.
> - At the coordinator's decision, reviewers may now **build the project and query values**. SETUP.md gives the pinned versions and steps. REVIEWER_GUIDE §6 gives the rules for reading values.
> - You, as Reviewer A, follow the same SETUP and allowed commands.
> - Disclose value access in the paper. It differs from the precommit's method-side ban on value execution, which still applies to the method and baselines.

People in this study (use these codes everywhere; no real names in any file):

| Code | Who | Guide |
| --- | --- | --- |
| Reviewer A | You (`<PSEUDONYM>`), first author | This document |
| Reviewer B | Your friend, independent reviewer | `02_REVIEWER_B_GUIDE.md` |
| Adjudicator C | A third person, not yet named, who is neither A nor B | `03_ADJUDICATOR_GUIDE.md` |

---

## 0. Rules you must never break

1. **Label before any method runs.** Do not run the method, the baselines, or any AI analysis on a held-out pair until both A's and B's worksheets for that pair are locked (§4).
2. **Don't look at AI output for held-out pairs.** This covers Claude, the other LLM, and Copilot. Jaffle Shop and CAL development outputs are fine because they are never scored.
3. **Don't discuss specific pairs with Reviewer B** until both worksheets are locked. Logistics are fine: how to open a file, what a word in the rubric means. If B asks a rubric question, answer it in writing and add it to the Q&A log (§3), so every reviewer gets the same answer.
4. **B labels offline, with no AI.** B doesn't label in the Claude chat and doesn't use ChatGPT, Copilot, or AI search summaries.
5. **You aren't the adjudicator,** and your label doesn't win a disagreement by default.
6. **Disclose it.** The paper states that the first author was Reviewer A (§7).

## 1. Before anything is sent (freeze the rubric)

- [ ] Reconcile the label definitions in `02_REVIEWER_B_GUIDE.md` §4 with the outline's §3 taxonomy. Both must use **identical wording**.
- [ ] Decide the substitutability scope: ungrouped only, or ungrouped plus each `metric_time` grain plus shared dimensions. B's guide assumes the second, marked `[CONFIRM]`. Remove the `[CONFIRM]` tags once decided.
- [ ] **Hold back three rulings until B's CAL worksheet is locked.** They settle exactly the points disputed on CAL-03 and CAL-02, so putting them in the guide beforehand would steer B's third-reviewer answer. After B's CAL worksheet is locked, decide them yourself, then send them to everyone in writing through the Q&A log:
  1. Is "with tax vs without tax" a scope variant or a different quantity (`related`)?
  2. Do two metrics count as `related` just because they share a table and grain?
  3. If an evidence gap probably doesn't change the label, is it `sufficient` or `needs_review`?
- [ ] Keep every example in the guides free of Jaffle metric names. The examples are deliberately generic (`sales`, `sales_eu`...).
- [ ] Record the SHA-256 of the three guides in the log (§5). **Don't edit them after that.** If a change is unavoidable, make a new version, log it, and send it to everyone at the same time.

## 2. Building a pair packet

Make one packet per batch. It is a folder or a ZIP containing:

- `README.txt`: the repository URL and **pinned commit SHA** for each pair, and the order in which to review the pairs.
- For each pair: the two metric names and, for each metric, the **file path and line range** of its YAML declaration. Add links to the pinned-commit GitHub URLs, like `https://github.com/<owner>/<repo>/blob/<sha>/<path>#L10-L20`, so B sees exactly the right bytes.
- A blank worksheet (copy the template from B's guide §8).

**Never put these in a packet:**
- method or baseline outputs;
- compiled SQL produced by our adapter;
- AI notes;
- your own labels;
- any hint of the "expected" answer;
- which pairs are CAL or practice pairs versus held-out pairs.

Also:
- **Randomise the pair order** and note the seed. Give each pair a neutral code like `P-01`, not a name that hints at the answer.
- Record the packet's SHA-256 in the log before sending it.

## 3. Calibration (practice round)

- B does the **Jaffle CAL-01/02/03 practice pairs** first, from a packet that uses the same bytes as the earlier CAL packet.
- **You can't be a blind reviewer on CAL.** You have seen the AI-drafted worksheet and the development outputs. Your CAL answers don't count.
- **B's CAL-03 answer can serve as the third, independent answer** in `/tmp/CAL-03_third_reviewer_escalation.md`. B hasn't seen either earlier worksheet, so B qualifies. Lock B's worksheet before B sees any other answer.
- After calibration, you may discuss the **rubric wording** with B. Don't discuss held-out pairs.
- Log every rubric clarification in a Q&A log (`QA_LOG.md`): the date, the question, the written answer, and who received it. Send each answer to both reviewers and the adjudicator.
- Practice answers are **never gold**.

## 4. Held-out labelling

The order of steps matters:

1. Send the packet to B, and record the timestamp and packet SHA-256.
2. Label the same packet yourself **before** running anything on those pairs. Use only the pinned YAML/SQL and official dbt docs. Record your start and end time and active minutes, as B does.
3. **Lock each worksheet** when it's finished:
   - compute its SHA-256;
   - log the SHA-256 with a UTC timestamp;
   - save a read-only copy (`chmod a-w`, or email it to yourself so there is an external timestamp).
4. B locks the same way: B sends the file to you, and you log its SHA-256 on receipt. B keeps their own copy.
5. Only after **both** worksheets are locked:
   - send both to Adjudicator C (§6);
   - then run the method and baselines.

If you realise you made a mistake after locking, don't edit the locked file. Put the correction in a separate `A_errata.md`, with a timestamp, and report it.

## 5. Coordinator log (`LABEL_LOG.md`)

| Event | UTC timestamp | File / packet | SHA-256 | By |
| --- | --- | --- | --- | --- |
| Guides frozen (01/02/03) | | | | A |
| CAL packet sent to B | | | | A |
| B CAL worksheet locked | | | | A |
| Held-out packet batch 1 sent to B | | | | A |
| A worksheet batch 1 locked | | | | A |
| B worksheet batch 1 received and locked | | | | A |
| Both released to C | | | | A |
| C decision record received and locked | | | | A |
| First method/baseline run on batch 1 | | | | A |

The paper cites this log, and the replication package includes it.

## 6. Adjudication handoff

- Send C **only**:
  - the three guides;
  - the packet;
  - both locked worksheets;
  - the Q&A log.
- Don't send C method outputs, AI notes, or your opinion.
- If C asks a clarifying question, send it to both reviewers in writing and forward both written answers to C.
- C's decision record is the gold label. You don't edit it.

## 7. What goes in the paper

Suggested disclosure text (adjust as needed):

> Two reviewers labelled each pair independently. Reviewer A is the first author; Reviewer B is an independent practitioner with SQL/dbt experience who did not contribute to the method. Both labelled from pinned public sources before any method or baseline was run on held-out pairs, and without AI assistance. Worksheets were hashed and time-stamped on completion. Disagreements were resolved by a third person (the adjudicator), who was neither reviewer. We report agreement between A and B, and as a sensitivity check we rescore all results against Reviewer B's labels alone.

Also:
- Report agreement between A and B on labels and on evidence status. With 16 pairs, give raw agreement plus the confusion table; kappa is unstable at this size.
- Report the sensitivity analysis (B-only gold).
- Keep the AI disclosure consistent: no AI produced any reviewer or adjudicator judgment.

## 8. Your checklist

- [ ] Rubric frozen and guides hashed (§1)
- [ ] Adjudicator C recruited: not you, not B, and has SQL/dbt literacy
- [ ] B briefed; B's CAL practice worksheet locked (it also serves as the CAL-03 third answer)
- [ ] Held-out pairs drawn (depends on the corpus decision)
- [ ] Batch packet built, randomised, and hashed
- [ ] A's and B's worksheets locked, then released to C
- [ ] C's decision record locked
- [ ] Only now: method and baselines run and scored
- [ ] Agreement and sensitivity analysis done, and the disclosure is in the paper
