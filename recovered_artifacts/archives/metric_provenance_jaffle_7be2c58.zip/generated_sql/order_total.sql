SELECT
  SUM(order_total) AS order_total
FROM "dev"."main"."orders" orders_src_10000
