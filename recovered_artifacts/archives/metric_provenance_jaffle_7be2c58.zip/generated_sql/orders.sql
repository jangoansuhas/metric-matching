SELECT
  SUM(1) AS orders
FROM "dev"."main"."orders" orders_src_10000
