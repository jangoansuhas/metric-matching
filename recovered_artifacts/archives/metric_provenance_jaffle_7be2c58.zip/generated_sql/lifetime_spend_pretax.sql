SELECT
  SUM(lifetime_spend_pretax) AS lifetime_spend_pretax
FROM "dev"."main"."customers" customers_src_10000
