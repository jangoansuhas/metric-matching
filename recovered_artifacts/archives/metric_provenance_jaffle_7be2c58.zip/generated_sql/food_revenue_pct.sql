SELECT
  CAST(SUM(case when is_food_item then product_price else 0 end) AS DOUBLE) / CAST(NULLIF(SUM(product_price), 0) AS DOUBLE) AS food_revenue_pct
FROM "dev"."main"."order_items" order_item_src_10000
