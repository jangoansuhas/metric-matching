SELECT
  SUM(product_price) AS revenue
FROM "dev"."main"."order_items" order_item_src_10000
