WITH sma_10002_cte AS (
  SELECT
    DATE_TRUNC('day', ordered_at) AS metric_time__day
    , product_price AS __revenue
  FROM "dev"."main"."order_items" order_item_src_10000
)

SELECT
  metric_time__day AS metric_time__day
  , (current_revenue - revenue_prev_month)*100/revenue_prev_month AS revenue_growth_mom
FROM (
  SELECT
    COALESCE(subq_5.metric_time__day, subq_15.metric_time__day) AS metric_time__day
    , MAX(subq_5.current_revenue) AS current_revenue
    , MAX(subq_15.revenue_prev_month) AS revenue_prev_month
  FROM (
    SELECT
      metric_time__day
      , SUM(__revenue) AS current_revenue
    FROM sma_10002_cte
    GROUP BY
      metric_time__day
  ) subq_5
  FULL OUTER JOIN (
    SELECT
      time_spine_src_10000.date_day AS metric_time__day
      , subq_9.__revenue AS revenue_prev_month
    FROM "dev"."main"."metricflow_time_spine" time_spine_src_10000
    INNER JOIN (
      SELECT
        metric_time__day
        , SUM(__revenue) AS __revenue
      FROM sma_10002_cte
      GROUP BY
        metric_time__day
    ) subq_9
    ON
      time_spine_src_10000.date_day - INTERVAL 1 month = subq_9.metric_time__day
  ) subq_15
  ON
    subq_5.metric_time__day = subq_15.metric_time__day
  GROUP BY
    COALESCE(subq_5.metric_time__day, subq_15.metric_time__day)
) subq_16
