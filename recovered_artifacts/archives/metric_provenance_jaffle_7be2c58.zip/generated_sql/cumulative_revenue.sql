SELECT
  SUM(product_price) AS cumulative_revenue
FROM "dev"."main"."order_items" order_item_src_10000
