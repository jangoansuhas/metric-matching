SELECT
  SUM(count_lifetime_orders) AS count_lifetime_orders
FROM "dev"."main"."customers" customers_src_10000
