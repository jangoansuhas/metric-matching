# All-metrics compiled provenance: Jaffle Shop (development only)

**Scope.** This is a technical run of the generic adapter `inputs/run_adapter.py` over every declared metric. It assigns **no** relationship labels (including CAL-03), it is **not** human adjudication, and no held-out repository was inspected. It includes CAL-01/02/03 metrics, so keep it away from the blind CAL-03 third reviewer until their worksheet is locked.

**Run by:** Claude (AI assistant) in the user's dev container. **Run window:** 2026-09-28 17:05:29Z – 17:06:41Z (UTC).

## 1. Inputs and environment

| Item | Value |
| --- | --- |
| Repository / commit | `https://github.com/dbt-labs/jaffle-shop.git` @ `7be2c5838dbdeca8e915d4e46db70e910753d7f6` (`git cat-file -t` → `commit`) |
| Export | `git archive` into a fresh directory; no `target/` in the export. Command, exit, and 68-entry file list: `logs/git_archive.exit`, `logs/git_archive_filelist.txt`. Archive tar SHA-256 `7af864659e9b579296bba0766181ec7dc155c00fc05aba267bda28a1b9f3e88e` (same as the earlier `order_cost` build). |
| Original inputs (`inputs/*.original`) | `dbt_project.yml` `f71f84b9…1122`; `packages.yml` `43c2cc27…2cce`; `package-lock.yml` `a1d44d11…50db` |
| Tooling | Python 3.12.3; `dbt-core 1.12.5`, `dbt-duckdb 1.11.0`, `metricflow 0.213.0`, `dbt-metricflow 0.15.0` (`mf --version` prints 0.15.0), `duckdb 1.5.6`. Full list: `logs/00_pip_freeze.stdout`. |
| OS | Ubuntu 24.04.5 LTS, Linux 6.10.14-linuxkit aarch64 |
| Profile | Generated `inputs/profiles.yml`: profile `default` (read from `dbt_project.yml`), `type: duckdb`, local file `dev.duckdb`. No credentials, no remote warehouse, no copied profile. |
| Environment | Every command ran with an explicit environment (the `env -i` equivalent), holding only `HOME` (temp), `PATH` (venv + `/usr/bin:/bin`), `LANG`, `DBT_PROFILES_DIR` (temp), `DBT_SEND_ANONYMOUS_USAGE_STATS=false`, and `DO_NOT_TRACK=1` (`run_metadata.json` → `clean_env`). No company `DBT_*` variables were inherited. |
| Adapter script | `inputs/run_adapter.py`, SHA-256 `7b90ef37dfb1cce9c0a15f211ef89fb56106a0f1eb8817ed0ae405ad05ce09fe` |

## 2. Commands and exit codes

| Tag | Command | Exit | Elapsed |
| --- | --- | --- | --- |
| `01_dbt_deps` | `dbt deps` | 0 | 8.04 s |
| `02_dbt_parse` | `dbt parse --no-partial-parse` | 0 | 4.66 s |
| `10_mf_explain_*` | `mf query --metrics <m> --explain`, once for each of the 19 metrics, plus 1 retry with `--group-by metric_time` | 19 × 0, 1 × 1 | 52.7 s total |
| `20_duckdb_inventory` | read-only `information_schema.tables` query on `dev.duckdb` after all explains | 0 | 0.14 s |

The one non-zero exit is the ungrouped `revenue_growth_mom` attempt (§5). Each command's stdout, stderr, and exit JSON is in `logs/`. The parse output contains four warning or deprecation lines, the same non-fatal classes seen in the `order_cost` build. It has no errors.

**Dependencies (effective).** `dbt deps` re-resolved from `packages.yml` and rewrote the lockfile, the same as the earlier build:

- `dbt_utils` installed 1.3.3; the committed lock has 1.1.1.
- `dbt_date` installed 0.17.1; the committed lock has 0.10.0.
- `audit_helper` (`revision: main`) installed `71817f0a7fa3df9f63adb90db0cf28f7423f720b`; the committed lock has `b8f3a33…`.

The new lock is `inputs/package-lock.yml.after_deps`, SHA-256 `67ecfc0a…1eef`. No declared dependency was edited.

## 3. Fresh artifacts

| Artifact | SHA-256 | Note |
| --- | --- | --- |
| `manifests/manifest.json` | `8cb6b5d2241c629b92b04bd87c10e39d57f88c6a996f3ec624d0042876811d42` | Copied immediately after parse. `invocation_id 409c3377-10ea-4c47-985b-9d6edcf83c8d`, `generated_at 2026-09-28T17:05:45.257153Z`. |
| `manifests/semantic_manifest.json` | `bfcc846a7e4425056d61cfaec2c1857f9328544315a18f83e075c09c36896e51` | |

Both hashes are identical after all 20 `mf` commands (`sha256_*_after_explain` in `run_metadata.json`), so the explain runs didn't modify the artifacts. No `dbt compile`, `seed`, `run`, or `build` was executed.

**Local warehouse file.** `mf` created `dev.duckdb` (12,288 bytes, SHA-256 `fffbb08d…3d9e`), which is included in the bundle. After all explains, `information_schema.tables` returned `[]` (`logs/20_duckdb_inventory.stdout`). So no relation existed or was needed to generate the SQL.

## 4. Provenance for all 19 declared metrics

The fresh semantic manifest has 19 metrics and 13 measures. Every input measure has exactly one owning semantic model. Declared line spans are text-located in the pinned YAML; dbt artifacts don't carry YAML line numbers.

| Metric | Type | Declared at | Input measures → owner semantic model | Manifest `depends_on` | Generated SQL |
| --- | --- | --- | --- | --- | --- |
| lifetime_spend_pretax | simple | customers.yml:73–78 | lifetime_spend_pretax → customers | semantic_model.customers | ungrouped |
| count_lifetime_orders | simple | customers.yml:79–84 | count_lifetime_orders → customers | semantic_model.customers | ungrouped |
| average_order_value | derived | customers.yml:85–93 | count_lifetime_orders, lifetime_spend_pretax → customers | metric.count_lifetime_orders, metric.lifetime_spend_pretax | ungrouped |
| order_total | simple | orders.yml:124–129 | order_total → orders | semantic_model.orders | ungrouped |
| new_customer_orders | simple | orders.yml:130–137 | order_count → orders | semantic_model.orders | ungrouped |
| large_orders | simple | orders.yml:138–145 | order_count → orders | semantic_model.orders | ungrouped |
| orders | simple | orders.yml:146–151 | order_count → orders | semantic_model.orders | ungrouped |
| food_orders | simple | orders.yml:152–159 | order_count → orders | semantic_model.orders | ungrouped |
| drink_orders | simple | orders.yml:160–167 | order_count → orders | semantic_model.orders | ungrouped |
| revenue | simple | order_items.yml:90–95 | revenue → order_item | semantic_model.order_item | ungrouped |
| order_cost | simple | order_items.yml:96–101 | order_cost → **orders** | semantic_model.orders | ungrouped |
| median_revenue | simple | order_items.yml:102–107 | median_revenue → order_item | semantic_model.order_item | ungrouped |
| food_revenue | simple | order_items.yml:108–113 | food_revenue → order_item | semantic_model.order_item | ungrouped |
| drink_revenue | simple | order_items.yml:114–119 | drink_revenue → order_item | semantic_model.order_item | ungrouped |
| food_revenue_pct | ratio | order_items.yml:122–128 | food_revenue, revenue → order_item | metric.food_revenue, metric.revenue | ungrouped |
| drink_revenue_pct | ratio | order_items.yml:129–135 | drink_revenue, revenue → order_item | metric.drink_revenue, metric.revenue | ungrouped |
| revenue_growth_mom | derived | order_items.yml:138–149 | revenue → order_item | metric.revenue | **metric_time only** |
| order_gross_profit | derived | order_items.yml:150–159 | revenue → order_item; order_cost → orders | metric.revenue, metric.order_cost | ungrouped |
| cumulative_revenue | cumulative | order_items.yml:162–167 | revenue → order_item | semantic_model.order_item | ungrouped |

In `depends_on`, the `jaffle_shop.` prefix is omitted. Machine-readable versions are in `provenance.csv` and `provenance.json`; the JSON adds agg, expr, `agg_time_dimension`, filters, input-metric offsets, node relation, and model node. Per-file SQL hashes are in `provenance.csv`.

**Summary: 19/19 declared metrics have MetricFlow-generated SQL from a fresh same-commit parse. 18 are ungrouped; `revenue_growth_mom` is generated only with `metric_time`.**

## 5. Findings worth noting (technical, not relationship labels)

1. **`revenue_growth_mom` has no ungrouped scalar.**
   - The ungrouped query fails with this MetricFlow error: "The query includes a metric 'revenue_growth_mom' that specifies a time offset in input metrics … However, group-by-items do not include 'metric_time'."
   - Its inputs are `revenue` (alias `current_revenue`) and `revenue` with `offset_window: 1 month` (alias `revenue_prev_month`), and its expression is `(current_revenue - revenue_prev_month)*100/revenue_prev_month`.
   - The `metric_time` SQL (`generated_sql/revenue_growth_mom__metric_time.sql`) joins `metricflow_time_spine` with `date_day - INTERVAL 1 month`.
   - Any comparison involving this metric therefore has to be made per time grain, not as a single value.
2. **`order_cost` is declared in `order_items.yml` but binds to the `orders` semantic model.** The binding comes from the fresh parse in this run, and it reproduces the earlier single-metric build. The generated SQL is `SELECT SUM(order_cost) AS order_cost FROM "dev"."main"."orders" orders_src_10000`.
3. **`order_gross_profit` spans two semantic models.** Its SQL is a `CROSS JOIN` of two scalar subqueries: `SUM(product_price)` over `order_items` and `SUM(order_cost)` over `orders`. The result is then `revenue - cost`.
4. **`cumulative_revenue` ungrouped SQL is identical to `revenue` apart from the alias.** The cumulative semantics only appear when a time grouping is added. The ungrouped scalar can't tell the two metrics apart.
5. **Shared measure, different filters.** `orders`, `new_customer_orders`, `large_orders`, `food_orders`, and `drink_orders` all use the `order_count` measure. They differ only in metric-level filters, which are recorded in `provenance.json`.

## 6. Reproducibility checks

This run was compared with two earlier runs of the adapter, `run_jaffle_20260928T161946Z` and `run_jaffle_20260928T162153Z`. Each used a fresh export, deps, and parse. The later of the two used the same logic apart from the added archive log and DuckDB inventory. Neither earlier bundle is included.

- `generated_sql/*.sql`: byte-identical across all three runs.
- Binding columns of `provenance.csv`: identical.
- `semantic_manifest.json`: identical, with the same SHA-256.
- `manifest.json`: hash differs, as expected, because `invocation_id` and timestamps differ.
- Against the earlier single-metric `order_cost` build, the generated SQL is identical except for the database name. The adapter's DuckDB file is `dev.duckdb` and the earlier build's was `jaffle_dev.duckdb`, so the relation is `"dev"."main"."orders"` here and `"jaffle_dev"."main"."orders"` there.

## 7. Remaining gaps

1. **No execution.** No seeds were loaded and no models were built. The SQL was generated but not run, so there are no metric values.
2. **Floating dependency.** `audit_helper` tracks `main`, and the committed lockfile is stale relative to `packages.yml` (§2).
3. **Engine-specific.** Generated SQL is for DuckDB only.
4. **Ungrouped queries only**, apart from the `revenue_growth_mom` retry. Time-grouped and dimension-grouped SQL was not generated for the other 18 metrics.
5. **YAML spans are text-located heuristics.** They were checked against the pinned files for the CAL metrics in the earlier build, but not independently re-verified for all 19 here.
6. **Single repository.** The adapter has been exercised only on Jaffle Shop. Its behaviour on other projects is untested; examples include projects with no `packages.yml`, a non-DuckDB-compatible SQL dialect, or legacy `metrics:` specs.
7. **Connection-free explain untested.** `mf` opened the local DuckDB file. The file is empty and included, but whether explain works with no connection at all wasn't tested.

## 8. Bundle contents

- `report.md`
- `run_metadata.json`: environment, commands, and hashes
- `provenance.json` and `provenance.csv`
- `generated_sql/`: 19 files
- `manifests/`: the parse-time manifest and semantic manifest
- `logs/`: stdout, stderr, and exit JSON for every command, the `git archive` record and file list, the DuckDB inventory, and dbt/mf project logs
- `dev.duckdb`: the empty local DuckDB file created by `mf`
- `inputs/`: original `dbt_project.yml`, `packages.yml`, and `package-lock.yml`; the lock after deps; `profiles.yml`; `run_adapter.py`
- `SHA256SUMS`: covers every file above and excludes itself. Check with `sha256sum -c SHA256SUMS` from the bundle root.
